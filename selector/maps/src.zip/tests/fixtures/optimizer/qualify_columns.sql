--------------------------------------
-- Qualify columns
--------------------------------------
SELECT a FROM x;
SELECT x.a AS a FROM x AS x;

SELECT "a" FROM x;
SELECT x."a" AS "a" FROM x AS x;

# execute: false
# schema: {"zz": {"a": "INT"}}
SELECT a FROM zz GROUP BY a ORDER BY a;
SELECT zz.a AS a FROM zz AS zz GROUP BY zz.a ORDER BY a;

# execute: false
# schema: {"xx": {"x": "INT"}, "yy": {"p": "INT"}}
SELECT x, p FROM (SELECT x from xx) xx CROSS JOIN yy;
SELECT xx.x AS x, yy.p AS p FROM (SELECT xx.x AS x FROM xx AS xx) AS xx CROSS JOIN yy AS yy;

SELECT a FROM x AS z;
SELECT z.a AS a FROM x AS z;

SELECT a AS a FROM x;
SELECT x.a AS a FROM x AS x;

SELECT x.a FROM x;
SELECT x.a AS a FROM x AS x;

SELECT x.a AS a FROM x;
SELECT x.a AS a FROM x AS x;

SELECT a AS b FROM x;
SELECT x.a AS b FROM x AS x;

# execute: false
SELECT 1, 2 + 3 FROM x;
SELECT 1 AS "1", 2 + 3 AS _col_1 FROM x AS x;

# execute: false
SELECT a + b FROM x;
SELECT x.a + x.b AS _col_0 FROM x AS x;

SELECT l.a FROM x l WHERE a IN (select a FROM x ORDER by a);
SELECT l.a AS a FROM x AS l WHERE l.a IN (SELECT x.a AS a FROM x AS x ORDER BY a);

# execute: false
SELECT a, SUM(b) FROM x WHERE a > 1 AND b > 1 GROUP BY a;
SELECT x.a AS a, SUM(x.b) AS _col_1 FROM x AS x WHERE x.a > 1 AND x.b > 1 GROUP BY x.a;

SELECT SUM(a) AS c FROM x HAVING SUM(a) > 3;
SELECT SUM(x.a) AS c FROM x AS x HAVING SUM(x.a) > 3;

SELECT SUM(a) AS a FROM x HAVING SUM(a) > 3;
SELECT SUM(x.a) AS a FROM x AS x HAVING SUM(x.a) > 3;

SELECT SUM(a) AS c FROM x HAVING c > 3;
SELECT SUM(x.a) AS c FROM x AS x HAVING SUM(x.a) > 3;

# execute: false
SELECT SUM(a) AS a FROM x HAVING a > 3;
SELECT SUM(x.a) AS a FROM x AS x HAVING SUM(x.a) > 3;

SELECT SUM(a) AS c FROM x HAVING SUM(b) > 3;
SELECT SUM(x.a) AS c FROM x AS x HAVING SUM(x.b) > 3;

SELECT a AS j, b FROM x ORDER BY j;
SELECT x.a AS j, x.b AS b FROM x AS x ORDER BY j;

SELECT a AS j, b AS a FROM x ORDER BY 1;
SELECT x.a AS j, x.b AS a FROM x AS x ORDER BY j;

SELECT a AS j, -b AS j FROM x GROUP BY 1, 2 ORDER BY 1, -b;
SELECT x.a AS j, -x.b AS j FROM x AS x GROUP BY x.a, -x.b ORDER BY 1, -x.b;

SELECT SUM(a) AS c, SUM(b) AS d FROM x ORDER BY 1, 2;
SELECT SUM(x.a) AS c, SUM(x.b) AS d FROM x AS x ORDER BY c, d;

# execute: false
SELECT CAST(a AS INT) FROM x ORDER BY a;
SELECT CAST(x.a AS INT) AS a FROM x AS x ORDER BY a;

# execute: false
SELECT SUM(a), SUM(b) AS c FROM x ORDER BY 1, 2;
SELECT SUM(x.a) AS _col_0, SUM(x.b) AS c FROM x AS x ORDER BY _col_0, c;

SELECT a AS j, b FROM x GROUP BY j, b;
SELECT x.a AS j, x.b AS b FROM x AS x GROUP BY x.a, x.b;

SELECT a, b FROM x GROUP BY 1, 2;
SELECT x.a AS a, x.b AS b FROM x AS x GROUP BY x.a, x.b;

SELECT a, b FROM x ORDER BY 1, 2;
SELECT x.a AS a, x.b AS b FROM x AS x ORDER BY a, b;

SELECT DISTINCT a AS c, b AS d FROM x ORDER BY 1;
SELECT DISTINCT x.a AS c, x.b AS d FROM x AS x ORDER BY c;

SELECT 2 FROM x GROUP BY 1;
SELECT 2 AS "2" FROM x AS x GROUP BY 1;

SELECT 'a' AS a FROM x GROUP BY 1;
SELECT 'a' AS a FROM x AS x GROUP BY 1;

SELECT NULL AS a FROM x GROUP BY 1;
SELECT NULL AS a FROM x AS x GROUP BY 1;

SELECT TRUE AS a FROM x GROUP BY 1;
SELECT TRUE AS a FROM x AS x GROUP BY 1;

# execute: false
# dialect: oracle
SELECT t."col" FROM tbl t;
SELECT T."col" AS "col" FROM TBL T;

# execute: false
# dialect: oracle
WITH base AS (SELECT x.dummy AS COL_1 FROM dual x) SELECT b."COL_1" FROM base b;
WITH BASE AS (SELECT X.DUMMY AS COL_1 FROM DUAL X) SELECT B."COL_1" AS "COL_1" FROM BASE B;

# execute: false
-- this query seems to be invalid in postgres and duckdb but valid in bigquery
SELECT 2 a FROM x GROUP BY 1 HAVING a > 1;
SELECT 2 AS a FROM x AS x GROUP BY 1 HAVING a > 1;

SELECT 2 d FROM x GROUP BY d HAVING d > 1;
SELECT 2 AS d FROM x AS x GROUP BY 1 HAVING d > 1;

SELECT 2 d FROM x GROUP BY 1 ORDER BY 1;
SELECT 2 AS d FROM x AS x GROUP BY 1 ORDER BY d;

# execute: false
SELECT DATE(a), DATE(b) AS c FROM x GROUP BY 1, 2;
SELECT DATE(x.a) AS _col_0, DATE(x.b) AS c FROM x AS x GROUP BY DATE(x.a), DATE(x.b);

# execute: false
SELECT (SELECT MIN(a) FROM UNNEST([1, 2]) AS t(a)) AS f FROM x GROUP BY 1;
SELECT (SELECT MIN(t.a) AS _col_0 FROM UNNEST(ARRAY(1, 2)) AS t(a)) AS f FROM x AS x GROUP BY 1;

# dialect: bigquery
WITH x AS (select 'a' as a, 1 as b) SELECT x.a AS c, y.a as d, SUM(x.b) AS y, FROM x join x as y on x.a = y.a group by 1, 2;
WITH x AS (SELECT 'a' AS a, 1 AS b) SELECT x.a AS c, y.a AS d, SUM(x.b) AS y FROM x AS x JOIN x AS y ON x.a = y.a GROUP BY x.a, 2;

SELECT SUM(x.a) AS c FROM x JOIN y ON x.b = y.b GROUP BY c;
SELECT SUM(x.a) AS c FROM x AS x JOIN y AS y ON x.b = y.b GROUP BY y.c;

SELECT COALESCE(x.a) AS d FROM x JOIN y ON x.b = y.b GROUP BY d;
SELECT COALESCE(x.a) AS d FROM x AS x JOIN y AS y ON x.b = y.b GROUP BY COALESCE(x.a);

# title: Aggregate alias must not be expanded into a GROUP BY (would nest the aggregate)
# execute: false
# validate_qualify_columns: false
SELECT SUM(x.a) AS d FROM x JOIN y ON x.b = y.b GROUP BY UPPER(d);
SELECT SUM(x.a) AS d FROM x AS x JOIN y AS y ON x.b = y.b GROUP BY UPPER(d);

# title: Standalone aggregate alias reference in GROUP BY must not be expanded
# execute: false
# validate_qualify_columns: false
SELECT SUM(x.a) AS d FROM x JOIN y ON x.b = y.b GROUP BY d;
SELECT SUM(x.a) AS d FROM x AS x JOIN y AS y ON x.b = y.b GROUP BY d;

# title: Aggregate alias colliding with a base column resolves the GROUP BY ref to the column
# execute: false
SELECT SUM(x.a) AS c FROM x JOIN y ON x.b = y.b GROUP BY UPPER(c);
SELECT SUM(x.a) AS c FROM x AS x JOIN y AS y ON x.b = y.b GROUP BY UPPER(y.c);

# title: Aggregate in a subquery scope does not block expanding an alias into GROUP BY
# dialect: duckdb
WITH x AS (SELECT * FROM (VALUES (1, 10), (2, 10), (3, 20)) AS v(a, b)) SELECT (SELECT MAX(t.a) FROM x AS t) + x.b AS f FROM x GROUP BY f ORDER BY f;
WITH x AS (SELECT v.a AS a, v.b AS b FROM (VALUES (1, 10), (2, 10), (3, 20)) AS v(a, b)) SELECT (SELECT MAX(t.a) AS _col_0 FROM x AS t) + x.b AS f FROM x AS x GROUP BY (SELECT MAX(t.a) AS _col_0 FROM x AS t) + x.b ORDER BY f;

SELECT a + 1 AS d FROM x WHERE d > 1;
SELECT x.a + 1 AS d FROM x AS x WHERE (x.a + 1) > 1;

# execute: false
SELECT a + 1 AS d, d + 2 FROM x;
SELECT x.a + 1 AS d, x.a + 1 + 2 AS _col_1 FROM x AS x;

SELECT a AS a, b FROM x ORDER BY a;
SELECT x.a AS a, x.b AS b FROM x AS x ORDER BY a;

SELECT a, b FROM x ORDER BY a;
SELECT x.a AS a, x.b AS b FROM x AS x ORDER BY a;

SELECT a FROM x ORDER BY b;
SELECT x.a AS a FROM x AS x ORDER BY x.b;

SELECT SUM(a) AS a FROM x ORDER BY SUM(a);
SELECT SUM(x.a) AS a FROM x AS x ORDER BY SUM(x.a);

# execute: false
SELECT AGGREGATE(ARRAY(a, x.b), 0, (x, acc) -> x + acc + a) AS sum_agg FROM x;
SELECT AGGREGATE(ARRAY(x.a, x.b), 0, (x, acc) -> x + acc + x.a) AS sum_agg FROM x AS x;

# dialect: starrocks
# execute: false
SELECT DATE_TRUNC('week', a) AS a FROM x;
SELECT DATE_TRUNC('WEEK', x.a) AS a FROM x AS x;

# dialect: bigquery
# execute: false
SELECT DATE_TRUNC(a, MONTH) AS a FROM x;
SELECT DATE_TRUNC(x.a, MONTH) AS a FROM x AS x;

# title: oracle cannot reference select aliases, so z is a source column
# dialect: oracle
# execute: false
# schema: {"t": {"z": "INT"}}
SELECT 1 AS z, z + 1 AS w FROM (SELECT * FROM t) c;
SELECT 1 AS Z, C.Z + 1 AS W FROM (SELECT T.Z AS Z FROM T T) C;

# execute: false
SELECT t.x FROM READ_PARQUET('path.parquet', hive_partition=1) AS t;
SELECT t.x AS x FROM READ_PARQUET('path.parquet', hive_partition = 1) AS t;

# dialect: duckdb
SELECT r FROM range(3) AS r(range);
SELECT r AS r FROM RANGE(0, 3) AS r(range);

# dialect: duckdb
SELECT r.range AS x FROM range(3) AS r ORDER BY SUM(x) OVER ();
SELECT r.range AS x FROM RANGE(0, 3) AS r ORDER BY SUM(x) OVER ();

# dialect: duckdb
SELECT range + 1 AS range FROM range(3) AS r;
SELECT r.range + 1 AS range FROM RANGE(0, 3) AS r;

# dialect: duckdb
SELECT range + 1 AS x FROM range(3) AS r(range) WHERE x > 1;
SELECT r.range + 1 AS x FROM RANGE(0, 3) AS r(range) WHERE (r.range + 1) > 1;

# dialect: duckdb
# execute: false
SELECT x, y + 1 FROM READ_PARQUET('data.parquet') AS r WHERE x > 0;
SELECT r.x AS x, r.y + 1 AS _col_1 FROM READ_PARQUET('data.parquet') AS r WHERE r.x > 0;

# dialect: duckdb
# execute: false
SELECT payload.field AS payload FROM READ_PARQUET('data.parquet') AS r;
SELECT r.payload.field AS payload FROM READ_PARQUET('data.parquet') AS r;

# dialect: duckdb
# execute: false
SELECT *, x FROM READ_PARQUET('data.parquet') AS r;
SELECT *, r.x AS x FROM READ_PARQUET('data.parquet') AS r;

# title: oracle WHERE column sharing a projection alias name is a source column
# dialect: oracle
# execute: false
# schema: {"t": {"z": "INT"}}
SELECT 1 AS z FROM (SELECT * FROM t) c WHERE z > 0;
SELECT 1 AS Z FROM (SELECT T.Z AS Z FROM T T) C WHERE C.Z > 0;

# title: Input columns take precedence inside DuckDB ORDER BY expressions
# dialect: duckdb
# execute: false
# schema: {"t": {"id": "INT", "email": "VARCHAR"}}
SELECT id AS email FROM t ORDER BY email LIKE 'a%' DESC, id;
SELECT t.id AS email FROM t AS t ORDER BY t.email LIKE 'a%' DESC, t.id;

# title: Input columns take precedence inside Postgres ORDER BY expressions
# dialect: postgres
# execute: false
# schema: {"t": {"id": "INT", "email": "VARCHAR"}}
SELECT id AS email FROM t ORDER BY email || '';
SELECT t.id AS email FROM t AS t ORDER BY t.email || '';

# title: Parenthesized DuckDB ORDER BY names still reference aliases
# dialect: duckdb
# execute: false
# schema: {"t": {"id": "INT", "email": "VARCHAR"}}
SELECT id AS email FROM t ORDER BY email, (email), 1;
SELECT t.id AS email FROM t AS t ORDER BY email, (email), email;

# title: Parenthesized Postgres ORDER BY names still reference aliases
# dialect: postgres
# execute: false
# schema: {"t": {"id": "INT", "email": "VARCHAR"}}
SELECT id AS email FROM t ORDER BY email, (email), 1;
SELECT t.id AS email FROM t AS t ORDER BY email, (email), email;

# title: Input columns take precedence inside DuckDB DISTINCT ON expressions
# dialect: duckdb
# execute: false
# schema: {"t": {"id": "INT", "email": "VARCHAR"}}
SELECT DISTINCT ON (email || '') id AS email FROM t;
SELECT DISTINCT ON (t.email || '') t.id AS email FROM t AS t;

# title: Input columns take precedence inside Postgres DISTINCT ON expressions
# dialect: postgres
# execute: false
# schema: {"t": {"id": "INT", "email": "VARCHAR"}}
SELECT DISTINCT ON (email || '') id AS email FROM t;
SELECT DISTINCT ON (t.email || '') t.id AS email FROM t AS t;

# title: Standalone DISTINCT ON names still reference aliases
# dialect: postgres
# execute: false
# schema: {"t": {"id": "INT", "email": "VARCHAR"}}
SELECT DISTINCT ON (email) id AS email FROM t;
SELECT DISTINCT ON (email) t.id AS email FROM t AS t;

# title: Snowflake ORDER BY alias bindings are preserved
# dialect: snowflake
# execute: false
# schema: {"t": {"id": "INT", "email": "VARCHAR"}}
SELECT id AS email FROM t ORDER BY email || '';
SELECT T.ID AS EMAIL FROM T AS T ORDER BY EMAIL || '';

# title: Spark ORDER BY alias bindings are preserved
# dialect: spark
# execute: false
# schema: {"t": {"id": "INT", "email": "VARCHAR"}}
SELECT id AS email FROM t ORDER BY email || '';
SELECT t.id AS email FROM t AS t ORDER BY email || '';

# title: ClickHouse aggregate arguments retain alias binding despite USING columns
# dialect: clickhouse
# execute: false
# schema: {"t": {"x": "INT", "k": "VARCHAR"}, "u": {"k": "VARCHAR"}}
SELECT x AS k FROM t JOIN u USING (k) GROUP BY x ORDER BY MAX(k);
SELECT t.x AS k FROM t AS t JOIN u AS u ON t.k = u.k GROUP BY t.x ORDER BY MAX(k);

# execute: false
select * from (values (1, 2));
SELECT _0._col_0 AS _col_0, _0._col_1 AS _col_1 FROM (VALUES (1, 2)) AS _0(_col_0, _col_1);

# execute: false
select * from (values (1, 2)) x;
SELECT x._col_0 AS _col_0, x._col_1 AS _col_1 FROM (VALUES (1, 2)) AS x(_col_0, _col_1);

# execute: false
# schema: {"t": {"data": "INT"}}
SELECT SOME_UDF(data).* FROM t;
SELECT SOME_UDF(t.data).* FROM t AS t;

# execute: false
SELECT p.* FROM p UNION ALL SELECT p2.* FROM p2;
SELECT p.* FROM p AS p UNION ALL SELECT p2.* FROM p2 AS p2;

# execute: false
# allow_partial_qualification: true
# validate_qualify_columns: false
SELECT a + 1 AS i, missing_column FROM x;
SELECT x.a + 1 AS i, missing_column AS missing_column FROM x AS x;

# execute: false
# dialect: clickhouse
# schema: {"arrays_test": {"s": "TEXT", "arr1": "ARRAY<TEXT>", "arr2": "ARRAY<TEXT>"}}
SELECT s, arr1, arr2 FROM arrays_test LEFT ARRAY JOIN arr1, arrays_test.arr2;
SELECT arrays_test.s AS s, arrays_test.arr1 AS arr1, arrays_test.arr2 AS arr2 FROM arrays_test AS arrays_test LEFT ARRAY JOIN arrays_test.arr1, arrays_test.arr2;

# execute: false
# dialect: snowflake
WITH employees AS (
    SELECT *
    FROM (VALUES ('President', 1, NULL),
                 ('Vice President Engineering', 10, 1),
                 ('Programmer', 100, 10),
                 ('QA Engineer', 101, 10),
                 ('Vice President HR', 20, 1),
                 ('Health Insurance Analyst', 200, 20)
    ) AS t(title, employee_ID, manager_ID)
)
SELECT
  employee_ID,
  manager_ID,
  title,
  level
FROM employees
START WITH title = 'President'
CONNECT BY manager_ID = PRIOR employee_id
ORDER BY
  employee_ID NULLS LAST;
WITH EMPLOYEES AS (SELECT T.TITLE AS TITLE, T.EMPLOYEE_ID AS EMPLOYEE_ID, T.MANAGER_ID AS MANAGER_ID FROM (VALUES ('President', 1, NULL), ('Vice President Engineering', 10, 1), ('Programmer', 100, 10), ('QA Engineer', 101, 10), ('Vice President HR', 20, 1), ('Health Insurance Analyst', 200, 20)) AS T(TITLE, EMPLOYEE_ID, MANAGER_ID)) SELECT EMPLOYEES.EMPLOYEE_ID AS EMPLOYEE_ID, EMPLOYEES.MANAGER_ID AS MANAGER_ID, EMPLOYEES.TITLE AS TITLE, LEVEL AS LEVEL FROM EMPLOYEES AS EMPLOYEES START WITH EMPLOYEES.TITLE = 'President' CONNECT BY EMPLOYEES.MANAGER_ID = PRIOR EMPLOYEES.EMPLOYEE_ID ORDER BY EMPLOYEE_ID;

# execute: false
# dialect: oracle
WITH
t1 AS (
  SELECT
    1 AS c1,
    1 AS c2,
    'Y' AS TOP_PARENT_INDICATOR,
    1 AS id
  FROM DUAL
),
t2 AS (
  SELECT
    1 AS c2,
    2 AS id
  FROM DUAL
)
SELECT t1.c1
FROM t1
LEFT JOIN t2 ON t1.c2 = t2.c2
WHERE (t1.TOP_PARENT_INDICATOR = 'Y' OR LEVEL = 1)
START WITH (t1.id IS NOT NULL)
CONNECT BY PRIOR t1.id = t2.id;
WITH T1 AS (SELECT 1 AS C1, 1 AS C2, 'Y' AS TOP_PARENT_INDICATOR, 1 AS ID FROM DUAL DUAL), T2 AS (SELECT 1 AS C2, 2 AS ID FROM DUAL DUAL) SELECT T1.C1 AS C1 FROM T1 T1 LEFT JOIN T2 T2 ON T1.C2 = T2.C2 WHERE (T1.TOP_PARENT_INDICATOR = 'Y' OR LEVEL = 1) START WITH (NOT T1.ID IS NULL) CONNECT BY PRIOR T1.ID = T2.ID;

# execute: false
# dialect: postgres
SELECT * FROM ROWS FROM (GENERATE_SERIES(1, 3), GENERATE_SERIES(10, 12)) AS t(a, b);
SELECT t.a AS a, t.b AS b FROM ROWS FROM (GENERATE_SERIES(1, 3), GENERATE_SERIES(10, 12)) AS t(a, b);

# execute: false
# dialect: postgres
SELECT r.v, r.idx FROM t, LATERAL UNNEST(t.a) WITH ORDINALITY AS r(v, idx);
SELECT r.v AS v, r.idx AS idx FROM t AS t, LATERAL UNNEST(t.a) WITH ORDINALITY AS r(v, idx);

# execute: false
# dialect: clickhouse
SELECT generate_series FROM generate_series(0, 10) AS g;
SELECT g.generate_series AS generate_series FROM generate_series(0, 10) AS g(generate_series);

# execute: false
# dialect: snowflake
# schema: {"quarterly_sales": {"amount": "DOUBLE", "quarter": "INT", "empid": "INT"}}
SELECT empid FROM quarterly_sales PIVOT(SUM(amount) FOR quarter IN (ANY ORDER BY quarter));
SELECT _0.EMPID AS EMPID FROM QUARTERLY_SALES AS QUARTERLY_SALES PIVOT(SUM(QUARTERLY_SALES.AMOUNT) FOR QUARTERLY_SALES.QUARTER IN (ANY ORDER BY QUARTER)) AS _0;

# execute: false
# schema: {"t": {"x": "DOUBLE"}}
SELECT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY x) AS x FROM t;
SELECT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY t.x) AS x FROM t AS t;

# execute: false
# dialect: bigquery
WITH t AS (SELECT 1 AS c) SELECT TO_JSON_STRING(t) FROM t;
WITH t AS (SELECT 1 AS c) SELECT TO_JSON_STRING(t) AS _col_0 FROM t AS t;

# execute: false
# dialect: bigquery
# schema: {"t": {"col1": "DATE", "col2": "TEXT"}}
SELECT DATE_TRUNC(col1, WEEK(MONDAY)), col2 FROM t;
SELECT DATE_TRUNC(t.col1, WEEK(MONDAY)) AS _col_0, t.col2 AS col2 FROM t AS t;

# execute: false
SELECT first, second FROM (SELECT 'val' AS col, STACK(2, 1, 2, 3) AS (first, second)) AS tbl;
SELECT tbl.first AS first, tbl.second AS second FROM (SELECT 'val' AS col, STACK(2, 1, 2, 3) AS (first, second)) AS tbl;

# execute: false
# dialect: postgres
WITH t AS (SELECT 1 AS c) SELECT t FROM t;
WITH t AS (SELECT 1 AS c) SELECT t AS t FROM t AS t;

# title: Postgres resolves outer columns before whole-row references to inner table aliases
# execute: false
# dialect: postgres
SELECT (SELECT x FROM (SELECT 1 AS y) AS x) AS v FROM (SELECT 2 AS x) AS t;
SELECT (SELECT t.x AS x FROM (SELECT 1 AS y) AS x) AS v FROM (SELECT 2 AS x) AS t;

# execute: false
# dialect: postgres
SELECT (SELECT x FROM (SELECT 1 AS y) AS x) AS v FROM (SELECT 2 AS z) AS t;
SELECT (SELECT x AS x FROM (SELECT 1 AS y) AS x) AS v FROM (SELECT 2 AS z) AS t;

# title: Postgres subqueries in JOIN ON cannot reference later sources
# execute: false
# dialect: postgres
SELECT t.y FROM (SELECT 1 AS y) AS t JOIN (SELECT 2 AS z) AS u ON (SELECT x FROM (SELECT NULL::INT AS y) AS x) IS NOT NULL JOIN (SELECT 3 AS x) AS v ON TRUE;
SELECT t.y AS y FROM (SELECT 1 AS y) AS t JOIN (SELECT 2 AS z) AS u ON (SELECT x AS x FROM (SELECT CAST(NULL AS INT) AS y) AS x) IS NOT NULL JOIN (SELECT 3 AS x) AS v ON TRUE;

# title: Postgres later sources do not make JOIN ON outer columns ambiguous
# execute: false
# dialect: postgres
SELECT t.y FROM (SELECT 1 AS y) AS t JOIN (SELECT 2 AS x) AS "U" ON (SELECT x FROM (SELECT 4 AS y) AS x) = 2 JOIN (SELECT 3 AS x) AS v ON TRUE;
SELECT t.y AS y FROM (SELECT 1 AS y) AS t JOIN (SELECT 2 AS x) AS "U" ON (SELECT "U".x AS x FROM (SELECT 4 AS y) AS x) = 2 JOIN (SELECT 3 AS x) AS v ON TRUE;

# title: Postgres nested JOIN ON subqueries skip invisible sources when resolving outer columns
# execute: false
# dialect: postgres
SELECT (SELECT t.y FROM (SELECT 1 AS y) AS t JOIN (SELECT 2 AS z) AS u ON (SELECT (SELECT x FROM (SELECT 4 AS y) AS x)) = 5 JOIN (SELECT 3 AS x) AS v ON TRUE) AS r FROM (SELECT 5 AS x) AS w;
SELECT (SELECT t.y AS y FROM (SELECT 1 AS y) AS t JOIN (SELECT 2 AS z) AS u ON (SELECT (SELECT w.x AS x FROM (SELECT 4 AS y) AS x) AS _col_0) = 5 JOIN (SELECT 3 AS x) AS v ON TRUE) AS r FROM (SELECT 5 AS x) AS w;

# title: Postgres JOIN ON subqueries cannot reference preceding comma-separated join groups
# execute: false
# dialect: postgres
SELECT a.y FROM (SELECT NULL::INT AS x, 1 AS y) AS a, (SELECT 2 AS z) AS t JOIN (SELECT 3 AS z) AS u ON (SELECT x FROM (SELECT 1 AS y) AS x) IS NOT NULL;
SELECT a.y AS y FROM (SELECT CAST(NULL AS INT) AS x, 1 AS y) AS a, (SELECT 2 AS z) AS t JOIN (SELECT 3 AS z) AS u ON (SELECT x AS x FROM (SELECT 1 AS y) AS x) IS NOT NULL;

# title: Postgres EXISTS in JOIN ON cannot reference preceding comma-separated sources
# execute: false
# dialect: postgres
SELECT 1 AS v FROM (SELECT 2 AS x) AS t, (SELECT 3 AS z) AS u JOIN (SELECT 4 AS w) AS w ON EXISTS (SELECT x FROM (SELECT 1 AS y) AS x);
SELECT 1 AS v FROM (SELECT 2 AS x) AS t, (SELECT 3 AS z) AS u JOIN (SELECT 4 AS w) AS w ON EXISTS(SELECT x AS x FROM (SELECT 1 AS y) AS x);

# title: Postgres EXISTS in a nested join cannot reference sources outside its join group
# execute: false
# dialect: postgres
SELECT 1 AS v FROM (SELECT 2 AS x) AS t JOIN ((SELECT 3 AS z) AS u JOIN (SELECT 4 AS w) AS w ON EXISTS (SELECT x FROM (SELECT 1 AS y) AS x)) ON TRUE;
SELECT 1 AS v FROM (SELECT 2 AS x) AS t JOIN ((SELECT 3 AS z) AS u JOIN (SELECT 4 AS w) AS w ON EXISTS(SELECT x AS x FROM (SELECT 1 AS y) AS x)) ON TRUE;

# title: Postgres nested joins resolve visible columns despite matching columns outside the group
# execute: false
# dialect: postgres
SELECT 1 AS v FROM (SELECT 2 AS x) AS t JOIN ((SELECT 3 AS z) AS u JOIN (SELECT 4 AS x) AS w ON (SELECT x FROM (SELECT 1 AS y) AS x) = 4) ON TRUE;
SELECT 1 AS v FROM (SELECT 2 AS x) AS t JOIN ((SELECT 3 AS z) AS u JOIN (SELECT 4 AS x) AS w ON (SELECT w.x AS x FROM (SELECT 1 AS y) AS x) = 4) ON TRUE;

# title: Postgres outer columns can come from a nested right join operand
# execute: false
# dialect: postgres
SELECT 1 AS v FROM (SELECT 2 AS x) AS t, (SELECT 3 AS z) AS u JOIN ((SELECT 4 AS w) AS w JOIN (SELECT 5 AS x) AS q ON TRUE) ON (SELECT x FROM (SELECT 1 AS y) AS x) = 5;
SELECT 1 AS v FROM (SELECT 2 AS x) AS t, (SELECT 3 AS z) AS u JOIN ((SELECT 4 AS w) AS w JOIN (SELECT 5 AS x) AS q ON TRUE) ON (SELECT q.x AS x FROM (SELECT 1 AS y) AS x) = 5;

# title: Postgres outer columns can come from a nested left join operand
# execute: false
# dialect: postgres
SELECT 1 AS v FROM (SELECT 2 AS x) AS t, ((SELECT 3 AS z) AS u JOIN (SELECT 5 AS x) AS q ON TRUE) JOIN (SELECT 4 AS w) AS w ON (SELECT x FROM (SELECT 1 AS y) AS x) = 5;
SELECT 1 AS v FROM (SELECT 2 AS x) AS t, ((SELECT 3 AS z) AS u JOIN (SELECT 5 AS x) AS q ON TRUE) JOIN (SELECT 4 AS w) AS w ON (SELECT q.x AS x FROM (SELECT 1 AS y) AS x) = 5;

# title: Postgres nested joins can resolve columns in an enclosing query
# execute: false
# dialect: postgres
SELECT (SELECT 1 FROM (SELECT 2 AS x) AS t JOIN ((SELECT 3 AS z) AS u JOIN (SELECT 4 AS w) AS w ON (SELECT x FROM (SELECT 1 AS y) AS x) = 5) ON TRUE) AS v FROM (SELECT 5 AS x) AS o;
SELECT (SELECT 1 AS "1" FROM (SELECT 2 AS x) AS t JOIN ((SELECT 3 AS z) AS u JOIN (SELECT 4 AS w) AS w ON (SELECT o.x AS x FROM (SELECT 1 AS y) AS x) = 5) ON TRUE) AS v FROM (SELECT 5 AS x) AS o;

# title: Postgres LATERAL subqueries see columns of preceding sources, but not their own or later ones
# execute: false
# dialect: postgres
SELECT s.x AS x FROM (SELECT 2 AS x) AS t, LATERAL (SELECT x FROM (SELECT 1 AS y) AS x) AS s;
SELECT s.x AS x FROM (SELECT 2 AS x) AS t, LATERAL (SELECT t.x AS x FROM (SELECT 1 AS y) AS x) AS s;

# execute: false
# dialect: postgres
SELECT l.x AS x FROM LATERAL (SELECT x FROM (SELECT 1 AS y) AS x) AS l;
SELECT l.x AS x FROM LATERAL (SELECT x AS x FROM (SELECT 1 AS y) AS x) AS l;

# execute: false
# dialect: postgres
SELECT l.x AS a, t.x AS b FROM LATERAL (SELECT x FROM (SELECT 1 AS y) AS x) AS l, (SELECT 2 AS x) AS t;
SELECT l.x AS a, t.x AS b FROM LATERAL (SELECT x AS x FROM (SELECT 1 AS y) AS x) AS l, (SELECT 2 AS x) AS t;

# execute: false
# dialect: postgres
SELECT (SELECT l.x AS x FROM LATERAL (SELECT x FROM (SELECT 1 AS y) AS x) AS l) AS v FROM (SELECT 2 AS x) AS t;
SELECT (SELECT l.x AS x FROM LATERAL (SELECT t.x AS x FROM (SELECT 1 AS y) AS x) AS l) AS v FROM (SELECT 2 AS x) AS t;

# execute: false
# dialect: postgres
SELECT (SELECT l.v AS v FROM LATERAL (SELECT x AS v FROM (SELECT 1 AS y) AS x) AS l, (SELECT 3 AS x) AS u) AS v FROM (SELECT 2 AS x) AS t;
SELECT (SELECT l.v AS v FROM LATERAL (SELECT t.x AS v FROM (SELECT 1 AS y) AS x) AS l, (SELECT 3 AS x) AS u) AS v FROM (SELECT 2 AS x) AS t;

# title: Postgres derived tables don't see the columns of their sibling sources
# execute: false
# dialect: postgres
SELECT (SELECT l.v AS r FROM (SELECT 3 AS x) AS u, (SELECT x AS v FROM (SELECT 1 AS y) AS x) AS l) AS r FROM (SELECT 2 AS x) AS t;
SELECT (SELECT l.v AS r FROM (SELECT 3 AS x) AS u, (SELECT t.x AS v FROM (SELECT 1 AS y) AS x) AS l) AS r FROM (SELECT 2 AS x) AS t;

# title: Postgres outer column is left as is when qualifying it would bind to an inner source
# execute: false
# dialect: postgres
SELECT (SELECT x FROM (SELECT 1 AS y) AS x) AS v FROM (SELECT 2 AS x) AS x;
SELECT (SELECT x AS x FROM (SELECT 1 AS y) AS x) AS v FROM (SELECT 2 AS x) AS x;

# title: Postgres propagated outer columns respect descendant table aliases
# execute: false
# dialect: postgres
SELECT (SELECT (SELECT x FROM (SELECT 1 AS y) AS t) FROM (SELECT 3 AS z) AS x) FROM (SELECT 2 AS x) AS t;
SELECT (SELECT (SELECT x AS x FROM (SELECT 1 AS y) AS t) AS _col_0 FROM (SELECT 3 AS z) AS x) AS _col_0 FROM (SELECT 2 AS x) AS t;

# title: Postgres propagated outer columns respect aliases between their owning and resolving scopes
# execute: false
# dialect: postgres
SELECT (SELECT (SELECT (SELECT x) FROM (SELECT 1 AS y) AS t) FROM (SELECT 3 AS z) AS x) FROM (SELECT 2 AS x) AS t;
SELECT (SELECT (SELECT (SELECT x AS x) AS _col_0 FROM (SELECT 1 AS y) AS t) AS _col_0 FROM (SELECT 3 AS z) AS x) AS _col_0 FROM (SELECT 2 AS x) AS t;

# title: Postgres propagated outer columns ignore aliases in sibling subqueries
# execute: false
# dialect: postgres
SELECT (SELECT (SELECT x) + (SELECT t.y FROM (SELECT 1 AS y) AS t) FROM (SELECT 3 AS z) AS x) FROM (SELECT 2 AS x) AS t;
SELECT (SELECT (SELECT t.x AS x) + (SELECT t.y AS y FROM (SELECT 1 AS y) AS t) AS _col_0 FROM (SELECT 3 AS z) AS x) AS _col_0 FROM (SELECT 2 AS x) AS t;

# title: DuckDB resolves whole-row references to inner table aliases before outer columns
# execute: false
# dialect: duckdb
SELECT (SELECT x FROM (SELECT 1 AS y) AS x) AS v FROM (SELECT 2 AS x) AS t;
SELECT (SELECT x AS x FROM (SELECT 1 AS y) AS x) AS v FROM (SELECT 2 AS x) AS t;

--------------------------------------
-- Derived tables
--------------------------------------
SELECT y.a AS a FROM (SELECT x.a AS a FROM x AS x) AS y;
SELECT y.a AS a FROM (SELECT x.a AS a FROM x AS x) AS y;

SELECT y.a AS a FROM (SELECT x.a AS a FROM x AS x) AS y(a);
SELECT y.a AS a FROM (SELECT x.a AS a FROM x AS x) AS y;

SELECT y.c AS c FROM (SELECT x.a AS a, x.b AS b FROM x AS x) AS y(c);
SELECT y.c AS c FROM (SELECT x.a AS c, x.b AS b FROM x AS x) AS y;

SELECT a FROM (SELECT a FROM x AS x) y;
SELECT y.a AS a FROM (SELECT x.a AS a FROM x AS x) AS y;

SELECT a FROM (SELECT a AS a FROM x);
SELECT _0.a AS a FROM (SELECT x.a AS a FROM x AS x) AS _0;

SELECT a FROM (SELECT a FROM (SELECT a FROM x));
SELECT _1.a AS a FROM (SELECT _0.a AS a FROM (SELECT x.a AS a FROM x AS x) AS _0) AS _1;

SELECT x.a FROM x AS x JOIN (SELECT * FROM x) AS y ON x.a = y.a;
SELECT x.a AS a FROM x AS x JOIN (SELECT x.a AS a, x.b AS b FROM x AS x) AS y ON x.a = y.a;

SELECT a FROM x as t1 /* there is comment */;
SELECT t1.a AS a FROM x AS t1 /* there is comment */;

--------------------------------------
-- Joins
--------------------------------------
SELECT a, c FROM x JOIN y ON x.b = y.b;
SELECT x.a AS a, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

SELECT a, c FROM x, y;
SELECT x.a AS a, y.c AS c FROM x AS x, y AS y;

--------------------------------------
-- Unions
--------------------------------------
SELECT a FROM x UNION SELECT a FROM x ORDER BY a;
SELECT x.a AS a FROM x AS x UNION SELECT x.a AS a FROM x AS x ORDER BY a;

SELECT a FROM x UNION SELECT a FROM x UNION SELECT a FROM x ORDER BY a;
SELECT x.a AS a FROM x AS x UNION SELECT x.a AS a FROM x AS x UNION SELECT x.a AS a FROM x AS x ORDER BY a;

SELECT a FROM (SELECT a FROM x UNION SELECT a FROM x) ORDER BY a;
SELECT _0.a AS a FROM (SELECT x.a AS a FROM x AS x UNION SELECT x.a AS a FROM x AS x) AS _0 ORDER BY a;

# title: nested subqueries in union
((select a from x where a < 1)) UNION ((select a from x where a > 2));
(SELECT x.a AS a FROM x AS x WHERE x.a < 1) UNION (SELECT x.a AS a FROM x AS x WHERE x.a > 2);


# dialect: bigquery
# execute: false
SELECT * FROM (SELECT 1 AS foo, 2 AS bar INNER UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz);
SELECT _0.bar AS bar FROM (SELECT 1 AS foo, 2 AS bar INNER UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) AS _0;

# dialect: bigquery
# execute: false
SELECT * FROM (SELECT 1 AS foo, 2 AS bar UNION ALL CORRESPONDING SELECT 3 AS bar, 4 AS baz);
SELECT _0.bar AS bar FROM (SELECT 1 AS foo, 2 AS bar INNER UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) AS _0;

# dialect: bigquery
# execute: false
SELECT * FROM (SELECT 1 AS foo, 2 AS bar LEFT UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz);
SELECT _0.foo AS foo, _0.bar AS bar FROM (SELECT 1 AS foo, 2 AS bar LEFT UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) AS _0;

# dialect: bigquery
# execute: false
SELECT * FROM (SELECT 1 AS foo, 2 AS bar FULL UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz);
SELECT _0.foo AS foo, _0.bar AS bar, _0.baz AS baz FROM (SELECT 1 AS foo, 2 AS bar FULL UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) AS _0;


# dialect: bigquery
# execute: false
SELECT * FROM (SELECT 1 AS foo, 2 AS bar LEFT UNION ALL CORRESPONDING SELECT 3 AS bar, 4 AS baz);
SELECT _0.foo AS foo, _0.bar AS bar FROM (SELECT 1 AS foo, 2 AS bar LEFT UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) AS _0;


# dialect: bigquery
# execute: false
SELECT * FROM (SELECT 1 AS foo, 2 AS bar FULL UNION ALL CORRESPONDING SELECT 3 AS bar, 4 AS baz);
SELECT _0.foo AS foo, _0.bar AS bar, _0.baz AS baz FROM (SELECT 1 AS foo, 2 AS bar FULL UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) AS _0;

# dialect: bigquery
# execute: false
SELECT * FROM (SELECT 1 AS foo, 2 AS bar FULL UNION ALL CORRESPONDING BY (foo, bar) SELECT 3 AS bar, 4 AS baz);
SELECT _0.foo AS foo, _0.bar AS bar FROM (SELECT 1 AS foo, 2 AS bar FULL UNION ALL BY NAME ON (foo, bar) SELECT 3 AS bar, 4 AS baz) AS _0;


# dialect: duckdb
SELECT * FROM (SELECT 1 AS foo, 2 AS bar UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) ORDER BY bar;
SELECT _0.foo AS foo, _0.bar AS bar, _0.baz AS baz FROM (SELECT 1 AS foo, 2 AS bar UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) AS _0 ORDER BY _0.bar;

# dialect: duckdb
SELECT baz FROM (SELECT 1 AS foo, 2 AS bar UNION BY NAME SELECT 3 AS bar, 4 AS baz) AS t ORDER BY baz;
SELECT t.baz AS baz FROM (SELECT 1 AS foo, 2 AS bar UNION BY NAME SELECT 3 AS bar, 4 AS baz) AS t ORDER BY baz;

# dialect: bigquery
# execute: false
SELECT * FROM (SELECT 1 AS foo, 2 AS bar FULL UNION ALL BY NAME ON (foo, bar) SELECT 3 AS bar, 4 AS baz);
SELECT _0.foo AS foo, _0.bar AS bar FROM (SELECT 1 AS foo, 2 AS bar FULL UNION ALL BY NAME ON (foo, bar) SELECT 3 AS bar, 4 AS baz) AS _0;

# dialect: bigquery
# execute: false
SELECT * FROM ((SELECT 1 AS foo, 2 AS bar LEFT UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) LEFT UNION ALL BY NAME ON (bar) SELECT 3 AS foo, 4 AS bar);
SELECT _0.bar AS bar FROM ((SELECT 1 AS foo, 2 AS bar LEFT UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) LEFT UNION ALL BY NAME ON (bar) SELECT 3 AS foo, 4 AS bar) AS _0;

# dialect: bigquery
# execute: false
SELECT * FROM ((SELECT 1 AS foo, 2 AS bar LEFT UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) FULL UNION ALL BY NAME ON (foo, qux) SELECT 3 AS qux, 4 AS bar);
SELECT _0.foo AS foo, _0.qux AS qux FROM ((SELECT 1 AS foo, 2 AS bar LEFT UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) FULL UNION ALL BY NAME ON (foo, qux) SELECT 3 AS qux, 4 AS bar) AS _0;

# title: parenthesized set operation operands with side & kind
# dialect: bigquery
# execute: false
SELECT * FROM ((SELECT 1 AS foo, 2 AS bar) FULL OUTER UNION ALL BY NAME (SELECT 3 AS bar, 4 AS baz));
SELECT _0.foo AS foo, _0.bar AS bar, _0.baz AS baz FROM ((SELECT 1 AS foo, 2 AS bar) FULL OUTER UNION ALL BY NAME (SELECT 3 AS bar, 4 AS baz)) AS _0;

# dialect: bigquery
# execute: false
SELECT * FROM (((SELECT 1 AS foo, 2 AS bar LEFT UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) FULL UNION ALL BY NAME ON (foo, qux) SELECT 3 AS qux, 4 AS bar) INNER UNION ALL BY NAME ON (foo) SELECT 6 AS foo);
SELECT _0.foo AS foo FROM (((SELECT 1 AS foo, 2 AS bar LEFT UNION ALL BY NAME SELECT 3 AS bar, 4 AS baz) FULL UNION ALL BY NAME ON (foo, qux) SELECT 3 AS qux, 4 AS bar) INNER UNION ALL BY NAME ON (foo) SELECT 6 AS foo) AS _0;

# Title: Nested set operations with modifiers
# dialect: bigquery
# execute: false
WITH t1 AS (SELECT 1 AS a, 2 AS b), t2 AS (SELECT 2 AS b, 3 AS c), t3 AS (SELECT 2 AS c, 3 AS d), t4 AS (SELECT 2 AS e, 3 AS f) SELECT * FROM ((SELECT * FROM t1 FULL OUTER UNION ALL BY NAME (SELECT * FROM t2 FULL OUTER UNION ALL BY NAME (SELECT * FROM t3 FULL OUTER UNION ALL BY NAME SELECT * FROM t4))));
WITH t1 AS (SELECT 1 AS a, 2 AS b), t2 AS (SELECT 2 AS b, 3 AS c), t3 AS (SELECT 2 AS c, 3 AS d), t4 AS (SELECT 2 AS e, 3 AS f) SELECT _0.a AS a, _0.b AS b, _0.c AS c, _0.d AS d, _0.e AS e, _0.f AS f FROM ((SELECT t1.a AS a, t1.b AS b FROM t1 AS t1 FULL OUTER UNION ALL BY NAME (SELECT t2.b AS b, t2.c AS c FROM t2 AS t2 FULL OUTER UNION ALL BY NAME (SELECT t3.c AS c, t3.d AS d FROM t3 AS t3 FULL OUTER UNION ALL BY NAME SELECT t4.e AS e, t4.f AS f FROM t4 AS t4))) AS _0);


# Title: Nested set operations with different modifiers (FULL + INNER)
# dialect: bigquery
# execute: false
WITH t1 AS (SELECT 1 AS a, 2 AS b), t2 AS (SELECT 2 AS b, 3 AS c), t3 AS (SELECT 2 AS c, 3 AS d), t4 AS (SELECT 2 AS e, 3 AS f) SELECT * FROM ((SELECT * FROM t1 FULL OUTER UNION ALL BY NAME (SELECT * FROM t2 INNER UNION ALL BY NAME (SELECT * FROM t3 FULL OUTER UNION ALL BY NAME SELECT * FROM t4))));
WITH t1 AS (SELECT 1 AS a, 2 AS b), t2 AS (SELECT 2 AS b, 3 AS c), t3 AS (SELECT 2 AS c, 3 AS d), t4 AS (SELECT 2 AS e, 3 AS f) SELECT _0.a AS a, _0.b AS b, _0.c AS c FROM ((SELECT t1.a AS a, t1.b AS b FROM t1 AS t1 FULL OUTER UNION ALL BY NAME (SELECT t2.b AS b, t2.c AS c FROM t2 AS t2 INNER UNION ALL BY NAME (SELECT t3.c AS c, t3.d AS d FROM t3 AS t3 FULL OUTER UNION ALL BY NAME SELECT t4.e AS e, t4.f AS f FROM t4 AS t4))) AS _0);

# Title: Nested set operations with different modifiers (FULL + LEFT)
# dialect: bigquery
# execute: false
WITH t1 AS (SELECT 1 AS a, 2 AS b, 3 AS c, 4 AS d), t2 AS (SELECT 2 AS b, 3 AS c), t3 AS (SELECT 2 AS c, 3 AS d), t4 AS (SELECT 2 AS d, 3 AS e) SELECT * FROM ((SELECT * FROM t1 FULL OUTER UNION ALL BY NAME (SELECT * FROM t2 FULL UNION ALL BY NAME (SELECT * FROM t3 LEFT UNION ALL BY NAME SELECT * FROM t4))));
WITH t1 AS (SELECT 1 AS a, 2 AS b, 3 AS c, 4 AS d), t2 AS (SELECT 2 AS b, 3 AS c), t3 AS (SELECT 2 AS c, 3 AS d), t4 AS (SELECT 2 AS d, 3 AS e) SELECT _0.a AS a, _0.b AS b, _0.c AS c, _0.d AS d FROM ((SELECT t1.a AS a, t1.b AS b, t1.c AS c, t1.d AS d FROM t1 AS t1 FULL OUTER UNION ALL BY NAME (SELECT t2.b AS b, t2.c AS c FROM t2 AS t2 FULL UNION ALL BY NAME (SELECT t3.c AS c, t3.d AS d FROM t3 AS t3 LEFT UNION ALL BY NAME SELECT t4.d AS d, t4.e AS e FROM t4 AS t4))) AS _0);

--------------------------------------
-- Subqueries
--------------------------------------
SELECT a FROM x WHERE b IN (SELECT c FROM y);
SELECT x.a AS a FROM x AS x WHERE x.b IN (SELECT y.c AS c FROM y AS y);

# execute: false
SELECT (SELECT c FROM y) FROM x;
SELECT (SELECT y.c AS c FROM y AS y) AS _col_0 FROM x AS x;

# execute: false
WITH t(c) AS (SELECT 1) SELECT (SELECT c) FROM t;
WITH t AS (SELECT 1 AS c) SELECT (SELECT t.c AS c) AS _col_0 FROM t AS t;

# execute: false
WITH t1(c1) AS (SELECT 1), t2(c2) AS (SELECT 2) SELECT (SELECT c1 FROM t2) FROM t1;
WITH t1 AS (SELECT 1 AS c1), t2 AS (SELECT 2 AS c2) SELECT (SELECT t1.c1 AS c1 FROM t2 AS t2) AS _col_0 FROM t1 AS t1;

SELECT a FROM (SELECT a FROM x) WHERE a IN (SELECT b FROM (SELECT b FROM y));
SELECT _1.a AS a FROM (SELECT x.a AS a FROM x AS x) AS _1 WHERE _1.a IN (SELECT _0.b AS b FROM (SELECT y.b AS b FROM y AS y) AS _0);

# dialect: mysql
# execute: false
SELECT * FROM table_a as A WHERE A.col1 IN (SELECT MAX(B.col2) FROM table_b as B UNION ALL SELECT MAX(C.col2) FROM table_b as C);
SELECT * FROM table_a AS `A` WHERE `A`.col1 IN (SELECT MAX(`B`.col2) AS _col_0 FROM table_b AS `B` UNION ALL SELECT MAX(`C`.col2) AS _col_0 FROM table_b AS `C`);

# Title: Unnest deep subquery
select * from x where b in ((((select b from y))));
SELECT x.a AS a, x.b AS b FROM x AS x WHERE x.b IN (SELECT y.b AS b FROM y AS y);

--------------------------------------
-- Correlated subqueries
--------------------------------------
SELECT a FROM x WHERE b IN (SELECT c FROM y WHERE y.b = x.a);
SELECT x.a AS a FROM x AS x WHERE x.b IN (SELECT y.c AS c FROM y AS y WHERE y.b = x.a);

SELECT a FROM x WHERE b IN (SELECT c FROM y WHERE y.b = a);
SELECT x.a AS a FROM x AS x WHERE x.b IN (SELECT y.c AS c FROM y AS y WHERE y.b = x.a);

SELECT a FROM x WHERE b IN (SELECT b FROM y AS x);
SELECT x.a AS a FROM x AS x WHERE x.b IN (SELECT x.b AS b FROM y AS x);

SELECT a FROM x AS i WHERE b IN (SELECT b FROM y AS j WHERE j.b IN (SELECT c FROM y AS k WHERE k.b = j.b));
SELECT i.a AS a FROM x AS i WHERE i.b IN (SELECT j.b AS b FROM y AS j WHERE j.b IN (SELECT k.c AS c FROM y AS k WHERE k.b = j.b));

# execute: false
SELECT (SELECT n.a FROM n WHERE n.id = m.id) FROM m AS m;
SELECT (SELECT n.a AS a FROM n AS n WHERE n.id = m.id) AS _col_0 FROM m AS m;

# title: correlated aggregate resolves to local source without schema
# execute: false
# schema: {"t": {"id": "INT", "name": "TEXT"}, "u": {"id": "INT", "name": "TEXT"}}
SELECT id FROM t WHERE id > (SELECT AVG(id) FROM u WHERE u.name = t.name);
SELECT t.id AS id FROM t AS t WHERE t.id > (SELECT AVG(u.id) AS _col_0 FROM u AS u WHERE u.name = t.name);

# title: correlated aggregate with self-correlation via alias
# execute: false
# schema: {"t": {"id": "INT", "k": "INT"}}
SELECT id FROM t WHERE id > (SELECT AVG(id) FROM t AS t2 WHERE t2.k = t.k);
SELECT t.id AS id FROM t AS t WHERE t.id > (SELECT AVG(t2.id) AS _col_0 FROM t AS t2 WHERE t2.k = t.k);

# title: correlated aggregate where inner column name matches outer table
# execute: false
# schema: {"t": {"id": "INT", "k": "INT"}, "u": {"u": "INT", "k": "INT"}}
SELECT id FROM t WHERE id > (SELECT AVG(u) FROM u WHERE u.k = t.k);
SELECT t.id AS id FROM t AS t WHERE t.id > (SELECT AVG(u.u) AS _col_0 FROM u AS u WHERE u.k = t.k);

--------------------------------------
-- Expand *
--------------------------------------
SELECT * FROM x;
SELECT x.a AS a, x.b AS b FROM x AS x;

SELECT x.* FROM x;
SELECT x.a AS a, x.b AS b FROM x AS x;

SELECT * FROM x JOIN y ON x.b = y.b;
SELECT x.a AS a, x.b AS b, y.b AS b, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

SELECT x.* FROM x JOIN y ON x.b = y.b;
SELECT x.a AS a, x.b AS b FROM x AS x JOIN y AS y ON x.b = y.b;

SELECT x.*, y.* FROM x JOIN y ON x.b = y.b;
SELECT x.a AS a, x.b AS b, y.b AS b, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

SELECT a FROM (SELECT * FROM x);
SELECT _0.a AS a FROM (SELECT x.a AS a, x.b AS b FROM x AS x) AS _0;

SELECT * FROM (SELECT a FROM x);
SELECT _0.a AS a FROM (SELECT x.a AS a FROM x AS x) AS _0;

SELECT * FROM x GROUP BY 1, 2;
SELECT x.a AS a, x.b AS b FROM x AS x GROUP BY x.a, x.b;

SELECT * FROM (SELECT * FROM x) AS s(a, b);
SELECT s.a AS a, s.b AS b FROM (SELECT x.a AS a, x.b AS b FROM x AS x) AS s;

# execute: false
SELECT * FROM (SELECT * FROM t) AS s(a, b);
SELECT s.a AS a, s.b AS b FROM (SELECT t.a AS a, t.b AS b FROM t AS t) AS s;

# execute: false
SELECT * FROM (SELECT * FROM t1 UNION ALL SELECT * FROM t2) AS s(b);
SELECT s.b AS b FROM (SELECT t1.b AS b FROM t1 AS t1 UNION ALL SELECT t2.b AS b FROM t2 AS t2) AS s;

# dialect: bigquery
# execute: false
WITH tbl1 AS (SELECT STRUCT(1 AS col1, 2 AS col2, Struct("test" AS col1, Struct(3 AS col2) AS lvl2) AS lvl1) AS col), tbl2 AS (SELECT STRUCT(1 AS col1, 2 AS col2, Struct("test" AS col1, Struct(3 AS col2) AS lvl2) AS lvl1) AS col) SELECT tbl1.col.*, tbl2.col.* FROM tbl1, tbl2;
WITH tbl1 AS (SELECT STRUCT(1 AS col1, 2 AS col2, Struct('test' AS col1, Struct(3 AS col2) AS lvl2) AS lvl1) AS col), tbl2 AS (SELECT STRUCT(1 AS col1, 2 AS col2, Struct('test' AS col1, Struct(3 AS col2) AS lvl2) AS lvl1) AS col) SELECT tbl1.col.col1 AS col1, tbl1.col.col2 AS col2, tbl1.col.lvl1 AS lvl1, tbl2.col.col1 AS col1, tbl2.col.col2 AS col2, tbl2.col.lvl1 AS lvl1 FROM tbl1 AS tbl1 CROSS JOIN tbl2 AS tbl2;

# dialect: bigquery
# execute: false
WITH tbl1 AS (SELECT STRUCT(1 AS col1, 2 AS col2, Struct("test" AS col1, Struct(3 AS col2) AS lvl2) AS lvl1, 3 AS col3) AS col) SELECT tbl1.col.lvl1.* FROM tbl1;
WITH tbl1 AS (SELECT STRUCT(1 AS col1, 2 AS col2, Struct('test' AS col1, Struct(3 AS col2) AS lvl2) AS lvl1, 3 AS col3) AS col) SELECT tbl1.col.lvl1.col1 AS col1, tbl1.col.lvl1.lvl2 AS lvl2 FROM tbl1 AS tbl1;

# dialect: bigquery
# execute: false
# title: Cannot expand struct star with unnamed fields
WITH tbl1 AS (SELECT STRUCT(1 AS col1, Struct(5 AS col1)) AS col) SELECT tbl1.col.* FROM tbl1;
WITH tbl1 AS (SELECT STRUCT(1 AS col1, Struct(5 AS col1)) AS col) SELECT tbl1.col.* FROM tbl1 AS tbl1;

# dialect: bigquery
# execute: false
# title: Cannot expand struct star with ambiguous fields
WITH tbl1 AS (SELECT STRUCT(1 AS col1, 2 AS col1) AS col) SELECT tbl1.col.* FROM tbl1;
WITH tbl1 AS (SELECT STRUCT(1 AS col1, 2 AS col1) AS col) SELECT tbl1.col.* FROM tbl1 AS tbl1;

# dialect: bigquery
# execute: false
# title: BigQuery - Expand struct literal
WITH tbl1 AS (SELECT STRUCT(1 AS f0, 2 as f1) AS col) SELECT tbl1.col.* from tbl1;
WITH tbl1 AS (SELECT STRUCT(1 AS f0, 2 AS f1) AS col) SELECT tbl1.col.f0 AS f0, tbl1.col.f1 AS f1 FROM tbl1 AS tbl1;

# dialect: bigquery
# execute: false
# title: BigQuery - Expand top level nested struct
SELECT one.* FROM structs;
SELECT structs.one.a_1 AS a_1, structs.one.b_1 AS b_1 FROM structs AS structs;

# dialect: bigquery
# execute: false
# title: BigQuery - Unreferenced CTE does not shadow struct column in star expansion
WITH one AS (SELECT 1 AS x) SELECT one.* FROM structs;
WITH one AS (SELECT 1 AS x) SELECT structs.one.a_1 AS a_1, structs.one.b_1 AS b_1 FROM structs AS structs;

# dialect: bigquery
# execute: false
# title: BigQuery - CTE in FROM takes precedence over struct column in star expansion
WITH one AS (SELECT 1 AS x) SELECT one.* FROM structs, one;
WITH one AS (SELECT 1 AS x) SELECT one.x AS x FROM structs AS structs CROSS JOIN one AS one;

# dialect: risingwave
# execute: false
# title: RisingWave - Expand top level nested struct
SELECT (one).* FROM structs;
SELECT (structs.one).a_1 AS a_1, (structs.one).b_1 AS b_1 FROM structs AS structs;

# dialect: risingwave
# execute: false
# title: RisingWave - Preserve struct field identifier quotes
SELECT (quoted).* FROM structs;
SELECT (structs.quoted)."foo bar" AS "foo bar" FROM structs AS structs;

# dialect: bigquery
# execute: false
# title: BigQuery - Expand midlevel struct
SELECT nested_0.nested_1.* FROM structs;
SELECT structs.nested_0.nested_1.a_2 AS a_2, structs.nested_0.nested_1.nested_2 AS nested_2 FROM structs AS structs;

# dialect: risingwave
# execute: false
# title: RisingWave - Expand midlevel struct
SELECT ((nested_0).nested_1).* FROM structs;
SELECT ((structs.nested_0).nested_1).a_2 AS a_2, ((structs.nested_0).nested_1).nested_2 AS nested_2 FROM structs AS structs;

# title: CSV files are not scanned by default
# execute: false
SELECT * FROM READ_CSV('file.csv');
SELECT * FROM READ_CSV('file.csv') AS _0;

# dialect: clickhouse
# Title: Expand tuples in VALUES using the structure provided
# execute: false
SELECT * FROM VALUES ('person String, place String', ('Noah', 'Paris'));
SELECT _0.person AS person, _0.place AS place FROM VALUES ('person String, place String', ('Noah', 'Paris')) AS _0(person, place);

# dialect: clickhouse
# Title: Expand tuples in VALUES using the default naming scheme in CH
# execute: false
SELECT * FROM VALUES ((1, 1), (2, 2));
SELECT _0.c1 AS c1, _0.c2 AS c2 FROM VALUES ((1, 1), (2, 2)) AS _0(c1, c2);

# dialect: clickhouse
# Title: Expand fields in VALUES using the default naming scheme in CH
# execute: false
SELECT * FROM VALUES (1, 2, 3);
SELECT _0.c1 AS c1 FROM VALUES ((1), (2), (3)) AS _0(c1);

# title: Expand PIVOT column combinations
# dialect: duckdb
WITH cities AS (SELECT * FROM (VALUES ('nl', 'amsterdam', 2000, 1005)) AS t(country, name, year, population)) SELECT * FROM cities PIVOT(SUM(population) AS total, COUNT(population) AS count FOR country IN ('nl', 'us') year IN (2000, 2010) name IN ('amsterdam', 'seattle'));
WITH cities AS (SELECT t.country AS country, t.name AS name, t.year AS year, t.population AS population FROM (VALUES ('nl', 'amsterdam', 2000, 1005)) AS t(country, name, year, population)) SELECT _0.nl_2000_amsterdam_total AS nl_2000_amsterdam_total, _0.nl_2000_amsterdam_count AS nl_2000_amsterdam_count, _0.nl_2000_seattle_total AS nl_2000_seattle_total, _0.nl_2000_seattle_count AS nl_2000_seattle_count, _0.nl_2010_amsterdam_total AS nl_2010_amsterdam_total, _0.nl_2010_amsterdam_count AS nl_2010_amsterdam_count, _0.nl_2010_seattle_total AS nl_2010_seattle_total, _0.nl_2010_seattle_count AS nl_2010_seattle_count, _0.us_2000_amsterdam_total AS us_2000_amsterdam_total, _0.us_2000_amsterdam_count AS us_2000_amsterdam_count, _0.us_2000_seattle_total AS us_2000_seattle_total, _0.us_2000_seattle_count AS us_2000_seattle_count, _0.us_2010_amsterdam_total AS us_2010_amsterdam_total, _0.us_2010_amsterdam_count AS us_2010_amsterdam_count, _0.us_2010_seattle_total AS us_2010_seattle_total, _0.us_2010_seattle_count AS us_2010_seattle_count FROM cities AS cities PIVOT(SUM(population) AS total, COUNT(population) AS count FOR country IN ('nl', 'us') year IN (2000, 2010) name IN ('amsterdam', 'seattle')) AS _0;

--------------------------------------
-- CTEs
--------------------------------------
WITH z AS (SELECT x.a AS a FROM x) SELECT z.a AS a FROM z;
WITH z AS (SELECT x.a AS a FROM x AS x) SELECT z.a AS a FROM z AS z;

WITH z(a) AS (SELECT a FROM x) SELECT * FROM z;
WITH z AS (SELECT x.a AS a FROM x AS x) SELECT z.a AS a FROM z AS z;

WITH z AS (SELECT a FROM x) SELECT * FROM z as q;
WITH z AS (SELECT x.a AS a FROM x AS x) SELECT q.a AS a FROM z AS q;

WITH z AS (SELECT a FROM x) SELECT * FROM z;
WITH z AS (SELECT x.a AS a FROM x AS x) SELECT z.a AS a FROM z AS z;

WITH z AS (SELECT a FROM x), q AS (SELECT * FROM z) SELECT * FROM q;
WITH z AS (SELECT x.a AS a FROM x AS x), q AS (SELECT z.a AS a FROM z AS z) SELECT q.a AS a FROM q AS q;

WITH z AS (SELECT * FROM x) SELECT * FROM z UNION SELECT * FROM z ORDER BY a, b;
WITH z AS (SELECT x.a AS a, x.b AS b FROM x AS x) SELECT z.a AS a, z.b AS b FROM z AS z UNION SELECT z.a AS a, z.b AS b FROM z AS z ORDER BY a, b;

WITH z AS (SELECT * FROM x), q AS (SELECT b FROM z) SELECT b FROM q;
WITH z AS (SELECT x.a AS a, x.b AS b FROM x AS x), q AS (SELECT z.b AS b FROM z AS z) SELECT q.b AS b FROM q AS q;

WITH z AS ((SELECT b FROM x UNION ALL SELECT b FROM y) ORDER BY b) SELECT * FROM z;
WITH z AS ((SELECT x.b AS b FROM x AS x UNION ALL SELECT y.b AS b FROM y AS y) ORDER BY b) SELECT z.b AS b FROM z AS z;

WITH cte(x) AS (SELECT 1) SELECT * FROM cte AS cte(a);
WITH cte AS (SELECT 1 AS x) SELECT cte.a AS a FROM cte AS cte(a);

WITH cte(x, y) AS (SELECT 1, 2) SELECT cte.* FROM cte AS cte(a);
WITH cte AS (SELECT 1 AS x, 2 AS y) SELECT cte.a AS a, cte.y AS y FROM cte AS cte(a);

-- Cannot pop table column aliases for recursive ctes (redshift).
WITH RECURSIVE cte(x) AS (SELECT 1), cte2(y) AS (SELECT 2) SELECT * FROM cte, cte2;
WITH RECURSIVE cte(x) AS (SELECT 1 AS x), cte2(y) AS (SELECT 2 AS y) SELECT cte.x AS x, cte2.y AS y FROM cte AS cte, cte2 AS cte2;

# execute: false
# schema: {"players": {"player": "STRUCT<name TEXT, asset STRUCT<info TEXT>>"}}
WITH player AS (SELECT player.name, player.asset.info FROM players) SELECT * FROM player;
WITH player AS (SELECT players.player.name AS name, players.player.asset.info AS info FROM players AS players) SELECT player.name AS name, player.info AS info FROM player AS player;

# execute: false
# schema: {"t1": {"c1": "INT"}}
WITH tesT AS (SELECT c1 FROM t1) SELECT c1 FROM test;
WITH test AS (SELECT t1.c1 AS c1 FROM t1 AS t1) SELECT test.c1 AS c1 FROM test AS test;

--------------------------------------
-- Except, Replace, Rename
--------------------------------------
# execute: false
SELECT * RENAME(a AS d) FROM x;
SELECT x.a AS d, x.b AS b FROM x AS x;

# execute: false
SELECT * EXCEPT(b) RENAME(a AS d) FROM x;
SELECT x.a AS d FROM x AS x;

SELECT x.* EXCEPT(a), y.* FROM x, y;
SELECT x.b AS b, y.b AS b, y.c AS c FROM x AS x, y AS y;

SELECT * EXCEPT(a) FROM x;
SELECT x.b AS b FROM x AS x;

# execute: false
SELECT * EXCEPT(x.a) FROM x AS x;
SELECT x.b AS b FROM x AS x;

# execute: false
SELECT * EXCEPT (y.b) FROM x AS x JOIN y AS y ON x.b = y.b;
SELECT x.a AS a, x.b AS b, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

# execute: false
SELECT * EXCEPT (b, y.c) FROM x AS x JOIN y AS y ON x.b = y.b;
SELECT x.a AS a FROM x AS x JOIN y AS y ON x.b = y.b;

# execute: false
# note: this query would fail in the engine level because there are 0 selected columns
SELECT * EXCEPT (a, b) FROM x;
SELECT * EXCEPT (a, b) FROM x AS x;

SELECT x.a, * EXCEPT (a) FROM x AS x LEFT JOIN x AS y USING (a);
SELECT x.a AS a, x.b AS b, y.b AS b FROM x AS x LEFT JOIN x AS y ON x.a = y.a;

SELECT COALESCE(CAST(t1.a AS VARCHAR), '') AS a, t2.* EXCEPT (a) FROM x AS t1, x AS t2;
SELECT COALESCE(CAST(t1.a AS VARCHAR), '') AS a, t2.b AS b FROM x AS t1, x AS t2;

# execute: false
SELECT * REPLACE(2 AS a) FROM x;
SELECT 2 AS a, x.b AS b FROM x AS x;

# execute: false
SELECT * EXCEPT (a, b) REPLACE (a AS a) FROM x;
SELECT * EXCEPT (a, b) REPLACE (x.a AS a) FROM x AS x;

# execute: false
SELECT * REPLACE(COALESCE(b, a) AS a, a as b) FROM x;
SELECT COALESCE(x.b, x.a) AS a, x.a AS b FROM x AS x;

# execute: false
SELECT * REPLACE(1 AS a) RENAME(b as alias_b) FROM x;
SELECT 1 AS a, x.b AS alias_b FROM x AS x;

# execute: false
SELECT * EXCEPT(a) REPLACE(COALESCE(a, b) AS b) RENAME(b AS new_b) FROM x;
SELECT COALESCE(x.a, x.b) AS new_b FROM x AS x;

# execute: false
SELECT * REPLACE(1 AS a, a AS b) RENAME(b AS new_b) FROM x;
SELECT 1 AS a, x.a AS new_b FROM x AS x;

# title: REPLACE of a USING column
# dialect: duckdb
# execute_min_python: 3.10
# note: DuckDB 1.4.5 returns duplicate USING columns with REPLACE.
SELECT * REPLACE(b * 2 AS b) FROM x JOIN y USING (b);
SELECT x.a AS a, COALESCE(x.b, y.b) * 2 AS b, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

# title: RENAME of a USING column
# dialect: duckdb
SELECT * RENAME(b AS new_b) FROM x FULL JOIN y USING (b);
SELECT x.a AS a, COALESCE(x.b, y.b) AS new_b, y.c AS c FROM x AS x FULL JOIN y AS y ON x.b = y.b;

# title: REPLACE and RENAME of a USING column
# dialect: snowflake
# execute: false
SELECT * REPLACE(b * 2 AS b) RENAME(b AS new_b) FROM x FULL JOIN y USING (b);
SELECT COALESCE(X.B, Y.B) * 2 AS NEW_B, X.A AS A, Y.C AS C FROM X AS X FULL JOIN Y AS Y ON X.B = Y.B;

# title: REPLACE only affects its own star
# dialect: duckdb
# execute_min_python: 3.10
SELECT * REPLACE(b * 2 AS b), * FROM x JOIN y USING (b);
SELECT x.a AS a, COALESCE(x.b, y.b) * 2 AS b, y.c AS c, x.a AS a, COALESCE(x.b, y.b) AS b, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

# title: RENAME only affects its own star
# dialect: duckdb
SELECT * RENAME(b AS new_b), * FROM x FULL JOIN y USING (b);
SELECT x.a AS a, COALESCE(x.b, y.b) AS new_b, y.c AS c, x.a AS a, COALESCE(x.b, y.b) AS b, y.c AS c FROM x AS x FULL JOIN y AS y ON x.b = y.b;

# title: REPLACE only affects its own qualified star
# dialect: duckdb
SELECT x.* REPLACE(b * 2 AS b), x.* FROM x;
SELECT x.a AS a, x.b * 2 AS b, x.a AS a, x.b AS b FROM x AS x;

# title: EXCLUDE only affects its own star
# dialect: duckdb
SELECT * EXCLUDE(b), * FROM x;
SELECT x.a AS a, x.a AS a, x.b AS b FROM x AS x;

--------------------------------------
-- Using
--------------------------------------
SELECT x.b FROM x JOIN y USING (b);
SELECT x.b AS b FROM x AS x JOIN y AS y ON x.b = y.b;

# execute: false
# schema: {"tbl1": {"a": "STRUCT<b STRUCT<c STRUCT<d STRUCT<f STRUCT<g INT>>>>>"}, "tbl2": {"g": "INT"}}
WITH cte AS (SELECT a.b.c.d.f.g FROM tbl1) SELECT g FROM (SELECT g FROM tbl2) tbl2 JOIN cte USING(g);
WITH cte AS (SELECT tbl1.a.b.c.d.f.g AS g FROM tbl1 AS tbl1) SELECT COALESCE(tbl2.g, cte.g) AS g FROM (SELECT tbl2.g AS g FROM tbl2 AS tbl2) AS tbl2 JOIN cte AS cte ON tbl2.g = cte.g;

SELECT x.b FROM x JOIN y USING (b) JOIN z USING (b);
SELECT x.b AS b FROM x AS x JOIN y AS y ON x.b = y.b JOIN z AS z ON COALESCE(x.b, y.b) = z.b;

SELECT b FROM x AS x2 JOIN y AS y2 USING (b);
SELECT COALESCE(x2.b, y2.b) AS b FROM x AS x2 JOIN y AS y2 ON x2.b = y2.b;

SELECT b FROM x JOIN y USING (b) WHERE b = 1 and y.b = 2;
SELECT COALESCE(x.b, y.b) AS b FROM x AS x JOIN y AS y ON x.b = y.b WHERE COALESCE(x.b, y.b) = 1 AND y.b = 2;

SELECT b FROM x JOIN y USING (b) JOIN z USING (b);
SELECT COALESCE(x.b, y.b, z.b) AS b FROM x AS x JOIN y AS y ON x.b = y.b JOIN z AS z ON COALESCE(x.b, y.b) = z.b;

# dialect: duckdb
SELECT * FROM x JOIN y USING(b);
SELECT x.a AS a, COALESCE(x.b, y.b) AS b, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

# title: USING columns after a comma join keep their position
SELECT * FROM w, x JOIN y USING (b);
SELECT w.d AS d, w.e AS e, x.a AS a, COALESCE(x.b, y.b) AS b, y.c AS c FROM w AS w, x AS x JOIN y AS y ON x.b = y.b;

SELECT x.* FROM x JOIN y USING(b);
SELECT x.a AS a, x.b AS b FROM x AS x JOIN y AS y ON x.b = y.b;

SELECT x.*, y.* FROM x JOIN y USING(b);
SELECT x.a AS a, x.b AS b, y.b AS b, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

SELECT y.* FROM x LEFT JOIN y USING(b);
SELECT y.b AS b, y.c AS c FROM x AS x LEFT JOIN y AS y ON x.b = y.b;

# dialect: duckdb
SELECT * FROM x LEFT JOIN y USING(b);
SELECT x.a AS a, COALESCE(x.b, y.b) AS b, y.c AS c FROM x AS x LEFT JOIN y AS y ON x.b = y.b;

SELECT b FROM x JOIN y USING(b);
SELECT COALESCE(x.b, y.b) AS b FROM x AS x JOIN y AS y ON x.b = y.b;

SELECT b, c FROM x JOIN y USING(b);
SELECT COALESCE(x.b, y.b) AS b, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

SELECT b, c FROM y JOIN z USING(b, c);
SELECT COALESCE(y.b, z.b) AS b, COALESCE(y.c, z.c) AS c FROM y AS y JOIN z AS z ON y.b = z.b AND y.c = z.c;

SELECT * FROM y JOIN z USING(b, c);
SELECT COALESCE(y.b, z.b) AS b, COALESCE(y.c, z.c) AS c FROM y AS y JOIN z AS z ON y.b = z.b AND y.c = z.c;

SELECT * FROM y JOIN z USING(b, c) WHERE b = 2 AND c = 3;
SELECT COALESCE(y.b, z.b) AS b, COALESCE(y.c, z.c) AS c FROM y AS y JOIN z AS z ON y.b = z.b AND y.c = z.c WHERE COALESCE(y.b, z.b) = 2 AND COALESCE(y.c, z.c) = 3;

-- We can safely convert `b` to `x.b` in the following two queries, because the original queries
-- would be invalid if `b` also existed in `t`'s schema (which we don't know), due to ambiguity.

# execute: false
SELECT b FROM x JOIN t USING(a);
SELECT x.b AS b FROM x AS x JOIN t AS t ON x.a = t.a;

# execute: false
SELECT b FROM t JOIN x USING(a);
SELECT x.b AS b FROM t AS t JOIN x AS x ON t.a = x.a;

# execute: false
SELECT a FROM t1 JOIN t2 USING(a);
SELECT COALESCE(t1.a, t2.a) AS a FROM t1 AS t1 JOIN t2 AS t2 ON t1.a = t2.a;

# title: Reuse the merged USING column without a known schema
# execute: false
SELECT a FROM t1 FULL JOIN t2 USING (a) JOIN t3 USING (a);
SELECT COALESCE(t1.a, t2.a, t3.a) AS a FROM t1 AS t1 FULL JOIN t2 AS t2 ON t1.a = t2.a JOIN t3 AS t3 ON COALESCE(t1.a, t2.a) = t3.a;

WITH m(a) AS (SELECT 1), n(b) AS (SELECT 1) SELECT * FROM m JOIN n AS foo(a) USING (a);
WITH m AS (SELECT 1 AS a), n AS (SELECT 1 AS b) SELECT COALESCE(m.a, foo.a) AS a FROM m AS m JOIN n AS foo(a) ON m.a = foo.a;

# title: coalesce the USING clause's columns (3 joins, 2 join columns)
WITH t1 AS (SELECT 'x' AS id, DATE '2024-01-01' AS foo, 000 AS value), t2 AS (SELECT 'x' AS id, DATE '2024-02-02' AS foo, 123 AS value), t3 AS (SELECT 'x' AS id, DATE '2024-02-02' AS foo, 456 AS value) SELECT * FROM t1 FULL OUTER JOIN t2 USING(id, foo) FULL OUTER JOIN t3 USING(id, foo);
WITH t1 AS (SELECT 'x' AS id, CAST('2024-01-01' AS DATE) AS foo, 000 AS value), t2 AS (SELECT 'x' AS id, CAST('2024-02-02' AS DATE) AS foo, 123 AS value), t3 AS (SELECT 'x' AS id, CAST('2024-02-02' AS DATE) AS foo, 456 AS value) SELECT COALESCE(t1.id, t2.id, t3.id) AS id, COALESCE(t1.foo, t2.foo, t3.foo) AS foo, t1.value AS value, t2.value AS value, t3.value AS value FROM t1 AS t1 FULL OUTER JOIN t2 AS t2 ON t1.id = t2.id AND t1.foo = t2.foo FULL OUTER JOIN t3 AS t3 ON COALESCE(t1.id, t2.id) = t3.id AND COALESCE(t1.foo, t2.foo) = t3.foo;

# title: coalesce the USING clause's columns (3 joins, 3 join columns)
WITH t1 AS (SELECT 'x' AS id, CAST('2024-01-01' AS DATE) AS foo, 000 AS value), t2 AS (SELECT 'x' AS id, CAST('2024-02-02' AS DATE) AS foo, 123 AS value), t3 AS (SELECT 'x' AS id, CAST('2024-02-02' AS DATE) AS foo, 456 AS value) SELECT * FROM t1 FULL OUTER JOIN t2 USING (id, foo, value) FULL OUTER JOIN t3 USING (id, foo, value);
WITH t1 AS (SELECT 'x' AS id, CAST('2024-01-01' AS DATE) AS foo, 000 AS value), t2 AS (SELECT 'x' AS id, CAST('2024-02-02' AS DATE) AS foo, 123 AS value), t3 AS (SELECT 'x' AS id, CAST('2024-02-02' AS DATE) AS foo, 456 AS value) SELECT COALESCE(t1.id, t2.id, t3.id) AS id, COALESCE(t1.foo, t2.foo, t3.foo) AS foo, COALESCE(t1.value, t2.value, t3.value) AS value FROM t1 AS t1 FULL OUTER JOIN t2 AS t2 ON t1.id = t2.id AND t1.foo = t2.foo AND t1.value = t2.value FULL OUTER JOIN t3 AS t3 ON COALESCE(t1.id, t2.id) = t3.id AND COALESCE(t1.foo, t2.foo) = t3.foo AND COALESCE(t1.value, t2.value) = t3.value;

# title: coalesce the USING clause's columns (4 joins, 2 join columns)
WITH t1 AS (SELECT 'x' AS id, CAST('2024-01-01' AS DATE) AS foo, 000 AS value), t2 AS (SELECT 'x' AS id, CAST('2024-02-02' AS DATE) AS foo, 123 AS value), t3 AS (SELECT 'x' AS id, CAST('2024-02-02' AS DATE) AS foo, 456 AS value), t4 AS (SELECT 'x' AS id, CAST('2024-03-03' AS DATE) AS foo, 789 AS value) SELECT * FROM t1 FULL OUTER JOIN t2 USING (id, foo) FULL OUTER JOIN t3 USING (id, foo) FULL OUTER JOIN t4 USING (id, foo);
WITH t1 AS (SELECT 'x' AS id, CAST('2024-01-01' AS DATE) AS foo, 000 AS value), t2 AS (SELECT 'x' AS id, CAST('2024-02-02' AS DATE) AS foo, 123 AS value), t3 AS (SELECT 'x' AS id, CAST('2024-02-02' AS DATE) AS foo, 456 AS value), t4 AS (SELECT 'x' AS id, CAST('2024-03-03' AS DATE) AS foo, 789 AS value) SELECT COALESCE(t1.id, t2.id, t3.id, t4.id) AS id, COALESCE(t1.foo, t2.foo, t3.foo, t4.foo) AS foo, t1.value AS value, t2.value AS value, t3.value AS value, t4.value AS value FROM t1 AS t1 FULL OUTER JOIN t2 AS t2 ON t1.id = t2.id AND t1.foo = t2.foo FULL OUTER JOIN t3 AS t3 ON COALESCE(t1.id, t2.id) = t3.id AND COALESCE(t1.foo, t2.foo) = t3.foo FULL OUTER JOIN t4 AS t4 ON COALESCE(t1.id, t2.id, t3.id) = t4.id AND COALESCE(t1.foo, t2.foo, t3.foo) = t4.foo;

# title: Name anonymous STRUCT fields if replacing USING columns
WITH t1 AS (SELECT 1 AS id), t2 AS (SELECT 2 AS id) SELECT STRUCT(id) AS my_field FROM t1 JOIN t2 USING (id);
WITH t1 AS (SELECT 1 AS id), t2 AS (SELECT 2 AS id) SELECT STRUCT(COALESCE(t1.id, t2.id) AS id) AS my_field FROM t1 AS t1 JOIN t2 AS t2 ON t1.id = t2.id;

# title: Do not rename aliased STRUCT fields if replacing USING columns
WITH t1 AS (SELECT 1 AS id), t2 AS (SELECT 2 AS id) SELECT STRUCT(id AS col) AS my_field FROM t1 JOIN t2 USING (id);
WITH t1 AS (SELECT 1 AS id), t2 AS (SELECT 2 AS id) SELECT STRUCT(COALESCE(t1.id, t2.id) AS col) AS my_field FROM t1 AS t1 JOIN t2 AS t2 ON t1.id = t2.id;

--------------------------------------
-- Natural join
--------------------------------------
-- A NATURAL JOIN is expanded to a USING join over the common columns.
SELECT b FROM x NATURAL JOIN y;
SELECT COALESCE(x.b, y.b) AS b FROM x AS x JOIN y AS y ON x.b = y.b;

# dialect: duckdb
SELECT * FROM x NATURAL JOIN y;
SELECT x.a AS a, COALESCE(x.b, y.b) AS b, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

SELECT a FROM x NATURAL JOIN z;
SELECT x.a AS a FROM x AS x JOIN z AS z ON x.b = z.b;

-- Chained NATURAL JOINs intersect against all columns accumulated so far, so the
-- second join's common columns include those contributed by y.
SELECT b FROM x NATURAL JOIN y NATURAL JOIN z;
SELECT COALESCE(x.b, y.b, z.b) AS b FROM x AS x JOIN y AS y ON x.b = y.b JOIN z AS z ON COALESCE(x.b, y.b) = z.b AND y.c = z.c;

-- No common columns: there is no USING list to expand into, so NATURAL is left
-- in place for the engine to reject or cross join as it sees fit.
# execute: false
SELECT a, d FROM x NATURAL LEFT JOIN w;
SELECT x.a AS a, w.d AS d FROM x AS x NATURAL LEFT JOIN w AS w;

-- An unknown schema on either side makes the common columns unknowable.
# execute: false
# validate_qualify_columns: false
SELECT * FROM x NATURAL JOIN unknown_table;
SELECT * FROM x AS x NATURAL JOIN unknown_table AS unknown_table;

# execute: false
# validate_qualify_columns: false
SELECT * FROM unknown_table NATURAL JOIN x;
SELECT * FROM unknown_table AS unknown_table NATURAL JOIN x AS x;

--------------------------------------
-- Hint with table reference
--------------------------------------
# dialect: spark
SELECT /*+ BROADCAST(y) */ x.b FROM x JOIN y ON x.b = y.b;
SELECT /*+ BROADCAST(y) */ x.b AS b FROM x AS x JOIN y AS y ON x.b = y.b;

--------------------------------------
-- UDTF
--------------------------------------
# execute: false
SELECT c FROM x LATERAL VIEW EXPLODE (a) AS c;
SELECT _0.c AS c FROM x AS x LATERAL VIEW EXPLODE(x.a) _0 AS c;

# execute: false
# schema: {"xx": {"a": "ARRAY<INT>"}}
SELECT c FROM xx LATERAL VIEW EXPLODE (a) AS c;
SELECT _0.c AS c FROM xx AS xx LATERAL VIEW EXPLODE(xx.a) _0 AS c;

# execute: false
SELECT c FROM x LATERAL VIEW EXPLODE (a) t AS c;
SELECT t.c AS c FROM x AS x LATERAL VIEW EXPLODE(x.a) t AS c;

# execute: false
SELECT aa FROM x, UNNEST(a) AS t(aa);
SELECT t.aa AS aa FROM x AS x, UNNEST(x.a) AS t(aa);

# dialect: bigquery
# execute: false
SELECT aa FROM x, UNNEST(a) AS aa;
SELECT aa AS aa FROM x AS x CROSS JOIN UNNEST(x.a) AS aa;

# dialect: bigquery
# execute: false
# schema: {"t": {"rel": "STRUCT<arr ARRAY<INT>>"}}
SELECT h FROM t, UNNEST(rel.arr) AS h;
SELECT h AS h FROM t AS t CROSS JOIN UNNEST(t.rel.arr) AS h;

# dialect: bigquery
# execute: false
# schema: {"t": {"rel": "STRUCT<deep STRUCT<arr ARRAY<INT>>>"}}
SELECT EXISTS(SELECT 1 FROM UNNEST(rel.deep.arr) AS h) FROM t;
SELECT EXISTS(SELECT 1 AS `1` FROM UNNEST(t.rel.deep.arr) AS h) AS _col_0 FROM t AS t;

# dialect: duckdb
# execute: false
# schema: {"t": {"rel": "STRUCT(a INT)"}}
SELECT v FROM t, LATERAL (SELECT rel.a AS v) AS l;
SELECT l.v AS v FROM t AS t, LATERAL (SELECT t.rel.a AS v) AS l;

# dialect: duckdb
# execute: false
# schema: {"t": {"rel": "STRUCT(arr INT[])"}}
SELECT v FROM t, UNNEST(rel.arr) AS l(v);
SELECT l.v AS v FROM t AS t JOIN UNNEST(t.rel.arr) AS l(v) ON TRUE;

# dialect: spark
# execute: false
# schema: {"t": {"rel": "STRUCT<arr: ARRAY<INT>>"}}
SELECT c FROM t LATERAL VIEW EXPLODE(rel.arr) l AS c;
SELECT l.c AS c FROM t AS t LATERAL VIEW EXPLODE(t.rel.arr) l AS c;

# dialect: bigquery
# execute: false
# schema: {"t": {"d": "DATE"}}
SELECT day FROM UNNEST(GENERATE_DATE_ARRAY((SELECT MIN(d) FROM t), CURRENT_DATE)) AS day;
SELECT day AS day FROM UNNEST(GENERATE_DATE_ARRAY((SELECT MIN(t.d) AS _col_0 FROM t AS t), CURRENT_DATE, INTERVAL '1' DAY)) AS day;

# dialect: bigquery
# execute: false
# schema: {"t": {"doc": "STRUCT<arr ARRAY<STRUCT<a INT64, b STRING>>>"}}
SELECT r.* FROM t, UNNEST(doc.arr) AS r;
SELECT r.a AS a, r.b AS b FROM t AS t CROSS JOIN UNNEST(t.doc.arr) AS r;

# dialect: bigquery
# execute: false
select * from unnest ([1, 2]) as x with offset;
SELECT x AS x, offset AS offset FROM UNNEST([1, 2]) AS x WITH OFFSET AS offset;

# dialect: bigquery
# execute: false
select * from unnest ([1, 2]) as x with offset as y;
SELECT x AS x, y AS y FROM UNNEST([1, 2]) AS x WITH OFFSET AS y;

# dialect: bigquery
# execute: false
select x, a, x.a from unnest([STRUCT(1 AS a)]) as x CROSS JOIN m;
SELECT x AS x, a AS a, x.a AS a FROM UNNEST([STRUCT(1 AS a)]) AS x CROSS JOIN m AS m;

# dialect: bigquery
# execute: false
WITH cte AS (SELECT [STRUCT(1 AS a)] AS x) select a, x, m.a from cte, UNNEST(x) AS m CROSS JOIN n;
WITH cte AS (SELECT [STRUCT(1 AS a)] AS x) SELECT a AS a, cte.x AS x, m.a AS a FROM cte AS cte CROSS JOIN UNNEST(cte.x) AS m CROSS JOIN n AS n;

# dialect: presto
SELECT x.a, i.b FROM x CROSS JOIN UNNEST(SPLIT(CAST(b AS VARCHAR), ',')) AS i(b);
SELECT x.a AS a, i.b AS b FROM x AS x CROSS JOIN UNNEST(SPLIT(CAST(x.b AS VARCHAR), ',')) AS i(b);

# execute: false
SELECT c FROM (SELECT 1 a) AS x LATERAL VIEW EXPLODE(a) AS c;
SELECT _0.c AS c FROM (SELECT 1 AS a) AS x LATERAL VIEW EXPLODE(x.a) _0 AS c;

# execute: false
SELECT * FROM foo(bar) AS t(c1, c2, c3);
SELECT t.c1 AS c1, t.c2 AS c2, t.c3 AS c3 FROM FOO(bar) AS t(c1, c2, c3);

# execute: false
SELECT c1, c3 FROM foo(bar) AS t(c1, c2, c3);
SELECT t.c1 AS c1, t.c3 AS c3 FROM FOO(bar) AS t(c1, c2, c3);

# dialect: redshift
# execute: false
SELECT c.f::VARCHAR(MAX) AS f, e AS e FROM a.b AS c, c.d AS e;
SELECT CAST(c.f AS VARCHAR(MAX)) AS f, e AS e FROM a.b AS c, c.d AS e;

# dialect: bigquery
WITH cte AS (SELECT 1 AS col) SELECT * FROM cte LEFT JOIN UNNEST((SELECT ARRAY_AGG(DISTINCT x) AS agg FROM UNNEST([1]) AS x WHERE col = 1)) AS unnested;
WITH cte AS (SELECT 1 AS col) SELECT cte.col AS col, unnested AS unnested FROM cte AS cte LEFT JOIN UNNEST((SELECT ARRAY_AGG(DISTINCT x) AS agg FROM UNNEST([1]) AS x WHERE cte.col = 1)) AS unnested;

# dialect: bigquery
SELECT * FROM UNNEST(ARRAY<STRUCT<percentile STRING, value INT64, score FLOAT64>>[("p10", 1, 0.0)]);
SELECT percentile AS percentile, value AS value, score AS score FROM UNNEST(ARRAY<STRUCT<percentile STRING, value INT64, score FLOAT64>>[('p10', 1, 0.0)]);

# dialect: bigquery
# execute: false
WITH scores AS (SELECT * FROM UNNEST((SELECT ARRAY<STRUCT<percentile STRING, value INT64, score FLOAT64>>[("p10", 1, 0.0)]))) SELECT percentile FROM scores;
WITH scores AS (SELECT percentile AS percentile, value AS value, score AS score FROM UNNEST((SELECT ARRAY<STRUCT<percentile STRING, value INT64, score FLOAT64>>[('p10', 1, 0.0)] AS _col_0))) SELECT scores.percentile AS percentile FROM scores AS scores;

--------------------------------------
-- Window functions
--------------------------------------
# title: ORDER BY in window function
SELECT a + 1 AS a, ROW_NUMBER() OVER (PARTITION BY b ORDER BY a) AS row_num FROM x ORDER BY a, row_num;
SELECT x.a + 1 AS a, ROW_NUMBER() OVER (PARTITION BY x.b ORDER BY x.a) AS row_num FROM x AS x ORDER BY a, row_num;

# dialect: bigquery
SELECT ROW_NUMBER() OVER (PARTITION BY a ORDER BY b) AS row_num FROM x QUALIFY row_num = 1;
SELECT ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.b) AS row_num FROM x AS x QUALIFY ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.b) = 1;

# dialect: bigquery
SELECT x.b, x.a FROM x LEFT JOIN y ON x.b = y.b QUALIFY ROW_NUMBER() OVER(PARTITION BY x.b ORDER BY x.a DESC) = 1 ORDER BY x.b, x.a;
SELECT x.b AS b, x.a AS a FROM x AS x LEFT JOIN y AS y ON x.b = y.b QUALIFY ROW_NUMBER() OVER (PARTITION BY x.b ORDER BY x.a DESC) = 1 ORDER BY x.b, x.a;

SELECT * FROM x QUALIFY COUNT(a) OVER (PARTITION BY b) > 1;
SELECT x.a AS a, x.b AS b FROM x AS x QUALIFY COUNT(x.a) OVER (PARTITION BY x.b) > 1;

# title: BigQuery alias expansion in QUALIFY with source shadowing
# dialect: bigquery
# execute: false
SELECT a, MAX(b) AS x FROM x GROUP BY a QUALIFY ROW_NUMBER() OVER (PARTITION BY x ORDER BY a) = 1;
SELECT x.a AS a, MAX(x.b) AS x FROM x AS x GROUP BY a QUALIFY ROW_NUMBER() OVER (PARTITION BY x ORDER BY a) = 1;

# title: BigQuery alias expansion in QUALIFY with source shadowing and GROUP BY positional ref
# dialect: bigquery
# execute: false
SELECT x.a, MAX(x.b) AS x FROM x GROUP BY 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY x ORDER BY a) = 1;
SELECT x.a AS a, MAX(x.b) AS x FROM x AS x GROUP BY 1 QUALIFY ROW_NUMBER() OVER (PARTITION BY x ORDER BY a) = 1;

--------------------------------------
-- Expand laterals
--------------------------------------
# execute: false
SELECT 2 AS d, d + 1 FROM x WHERE d = 2 GROUP BY d;
SELECT 2 AS d, 2 + 1 AS _col_1 FROM x AS x WHERE 2 = 2 GROUP BY 1;

# title: expand alias reference
SELECT
  x.a + 1 AS i,
  i + 1 AS j,
  j + 1 AS k
FROM x;
SELECT x.a + 1 AS i, x.a + 1 + 1 AS j, x.a + 1 + 1 + 1 AS k FROM x AS x;

# title: noop - reference comes before alias
# execute: false
# validate_qualify_columns: false
SELECT i + 1 AS j, x.a + 1 AS i FROM x;
SELECT i + 1 AS j, x.a + 1 AS i FROM x AS x;

# title: subquery
SELECT
  *
FROM (
  SELECT
    x.a + 1 AS i,
    i + 1 AS j
  FROM x
);
SELECT _0.i AS i, _0.j AS j FROM (SELECT x.a + 1 AS i, x.a + 1 + 1 AS j FROM x AS x) AS _0;

# title: wrap expanded alias to ensure operator precedence isnt broken
# execute: false
SELECT x.a + x.b AS f, f * x.b FROM x;
SELECT x.a + x.b AS f, (x.a + x.b) * x.b AS _col_1 FROM x AS x;

# title: no need to wrap expanded alias
# execute: false
SELECT x.a + x.b AS f, f, f + 5 FROM x;
SELECT x.a + x.b AS f, x.a + x.b AS _col_1, x.a + x.b + 5 AS _col_2 FROM x AS x;

# title: expand double agg if window func
SELECT a, SUM(b) AS c, SUM(c) OVER(PARTITION BY a) AS d from x group by 1 ORDER BY a;
SELECT x.a AS a, SUM(x.b) AS c, SUM(SUM(x.b)) OVER (PARTITION BY x.a) AS d FROM x AS x GROUP BY x.a ORDER BY a;

# title: we can't expand aliases corresponding to recursive CTE columns (CTE names output columns)
# execute: false
WITH RECURSIVE t(c) AS (SELECT 1 AS c UNION ALL SELECT c + 1 AS c FROM t WHERE c <= 10) SELECT c FROM t;
WITH RECURSIVE t(c) AS (SELECT 1 AS c UNION ALL SELECT t.c + 1 AS c FROM t AS t WHERE t.c <= 10) SELECT t.c AS c FROM t AS t;

# title: we can't expand aliases corresponding to recursive CTE columns (CTE doesn't name output columns)
# execute: false
WITH RECURSIVE t AS (SELECT 1 AS c UNION ALL SELECT c + 1 AS c FROM t WHERE c <= 10) SELECT c FROM t;
WITH RECURSIVE t AS (SELECT 1 AS c UNION ALL SELECT t.c + 1 AS c FROM t AS t WHERE t.c <= 10) SELECT t.c AS c FROM t AS t;

# title: expand DISTINCT ON ordinals / projection names
SELECT DISTINCT ON (new_col, b + 1, 1) t1.a AS new_col FROM x AS t1 ORDER BY new_col;
SELECT DISTINCT ON (new_col, t1.b + 1, new_col) t1.a AS new_col FROM x AS t1 ORDER BY new_col;

# title: ORDER BY matches original JSON keys
# dialect: duckdb
# execute: false
# schema: {"t": {"k": "INT", "j": "JSON"}}
SELECT k, ANY_VALUE(j.Foo) AS v FROM t GROUP BY k ORDER BY ANY_VALUE(j.Foo), ANY_VALUE(j.foo);
SELECT t.k AS k, ANY_VALUE(t.j.foo) AS v FROM t AS t GROUP BY t.k ORDER BY v, ANY_VALUE(t.j.foo);

# title: ORDER BY preserves BigQuery JSON key case
# dialect: bigquery
# execute: false
# schema: {"t": {"k": "INT", "j": "JSON"}}
SELECT k, ANY_VALUE(j.Foo) AS v FROM t GROUP BY k ORDER BY ANY_VALUE(j.Foo), ANY_VALUE(j.foo);
SELECT t.k AS k, ANY_VALUE(t.j.`Foo`) AS v FROM t AS t GROUP BY k ORDER BY v, ANY_VALUE(t.j.`foo`);

# title: DISTINCT ON distinguishes swapped JSON keys
# dialect: duckdb
# execute: false
# schema: {"t": {"k": "INT", "j": "JSON"}}
SELECT DISTINCT ON (ANY_VALUE(j.Foo || j.foo), ANY_VALUE(j.foo || j.Foo)) k, ANY_VALUE(j.Foo || j.foo) AS v FROM t GROUP BY k;
SELECT DISTINCT ON (v, ANY_VALUE(t.j.foo || t.j.foo)) t.k AS k, ANY_VALUE(t.j.foo || t.j.foo) AS v FROM t AS t GROUP BY t.k;

# title: ORDER BY aggregate argument shares the projection alias
SELECT a, SUM(b) AS b FROM x GROUP BY a ORDER BY SUM(b);
SELECT x.a AS a, SUM(x.b) AS b FROM x AS x GROUP BY x.a ORDER BY b;

# title: qualify columns for Aggregate Functions and DISTINCT
SELECT COALESCE(COUNT(DISTINCT a)) AS a FROM x;
SELECT COALESCE(COUNT(DISTINCT x.a)) AS a FROM x AS x;

# title: Oracle does not support lateral alias expansion
# dialect: oracle
# execute: false
# schema: {"c": {"a": "INT", "b": "INT"}}
SELECT a AS b, b AS a FROM c;
SELECT C.A AS B, C.B AS A FROM C C;

# title: enable aliases expansion for the base case of recursive CTE
WITH RECURSIVE rec AS (SELECT id, parent_id AS parent, 1 AS level FROM (SELECT 1 AS id, 0 AS parent_id) AS t WHERE parent = 0 UNION ALL SELECT rec.id + 10 AS id, rec.id AS parent, rec.level + 1 AS level FROM rec WHERE level < 3) SELECT * FROM rec;
WITH RECURSIVE rec AS (SELECT t.id AS id, t.parent_id AS parent, 1 AS level FROM (SELECT 1 AS id, 0 AS parent_id) AS t WHERE t.parent_id = 0 UNION ALL SELECT rec.id + 10 AS id, rec.id AS parent, rec.level + 1 AS level FROM rec AS rec WHERE rec.level < 3) SELECT rec.id AS id, rec.parent AS parent, rec.level AS level FROM rec AS rec;

WITH RECURSIVE rec AS (SELECT id, parent_id AS parent, 1 AS level FROM (SELECT 1 AS id, 0 AS parent_id) AS t WHERE parent = 0 UNION ALL SELECT num, val AS x, 2 AS level FROM (SELECT 2 AS num, 1 AS val) AS s WHERE x = 1 UNION ALL SELECT rec.id + 10 AS id, rec.id AS parent, rec.level + 1 AS level FROM rec WHERE rec.level < 3) SELECT * FROM rec ORDER BY rec.id;
WITH RECURSIVE rec AS (SELECT t.id AS id, t.parent_id AS parent, 1 AS level FROM (SELECT 1 AS id, 0 AS parent_id) AS t WHERE t.parent_id = 0 UNION ALL SELECT s.num AS num, s.val AS x, 2 AS level FROM (SELECT 2 AS num, 1 AS val) AS s WHERE s.val = 1 UNION ALL SELECT rec.id + 10 AS id, rec.id AS parent, rec.level + 1 AS level FROM rec AS rec WHERE rec.level < 3) SELECT rec.id AS id, rec.parent AS parent, rec.level AS level FROM rec AS rec ORDER BY rec.id;

WITH RECURSIVE t(c) AS (SELECT 1 AS c UNION ALL SELECT * FROM (SELECT c + 1 AS c FROM t WHERE c <= 3 UNION ALL SELECT c + 2 AS c FROM t WHERE c <= 3)) SELECT c FROM t ORDER BY c;
WITH RECURSIVE t(c) AS (SELECT 1 AS c UNION ALL SELECT _0.c AS c FROM (SELECT t.c + 1 AS c FROM t AS t WHERE t.c <= 3 UNION ALL SELECT t.c + 2 AS c FROM t AS t WHERE t.c <= 3) AS _0) SELECT t.c AS c FROM t AS t ORDER BY c;

--------------------------------------
-- Wrapped tables / join constructs
--------------------------------------
# execute: false
SELECT * FROM ((tbl));
SELECT * FROM ((tbl AS tbl));

SELECT a, c FROM (x LEFT JOIN y ON a = c);
SELECT x.a AS a, y.c AS c FROM (x AS x LEFT JOIN y AS y ON x.a = y.c);

# execute: false
SELECT * FROM ((a CROSS JOIN ((b CROSS JOIN c) CROSS JOIN (d CROSS JOIN e))));
SELECT * FROM ((a AS a CROSS JOIN ((b AS b CROSS JOIN c AS c) CROSS JOIN (d AS d CROSS JOIN e AS e))));

# execute: false
SELECT * FROM ((SELECT * FROM tbl));
SELECT * FROM ((SELECT * FROM tbl AS tbl) AS _0);

# execute: false
# schema: {"t1": {"c": "INT"}}
SELECT * FROM ((SELECT c FROM t1) CROSS JOIN t2);
SELECT * FROM ((SELECT t1.c AS c FROM t1 AS t1) AS _0 CROSS JOIN t2 AS t2);

# execute: false
SELECT * FROM ((SELECT * FROM x) INNER JOIN y ON a = c);
SELECT _0.a AS a, _0.b AS b, y.b AS b, y.c AS c FROM ((SELECT x.a AS a, x.b AS b FROM x AS x) AS _0 INNER JOIN y AS y ON _0.a = y.c);

SELECT * FROM (SELECT a FROM x) AS s CROSS JOIN w;
SELECT s.a AS a, w.d AS d, w.e AS e FROM (SELECT x.a AS a FROM x AS x) AS s CROSS JOIN w AS w;

SELECT * FROM UNNEST(ARRAY(1, 2)) AS u(v) CROSS JOIN x;
SELECT u.v AS v, x.a AS a, x.b AS b FROM UNNEST(ARRAY(1, 2)) AS u(v) CROSS JOIN x AS x;

SELECT * FROM ((SELECT a FROM x) CROSS JOIN y) AS j;
SELECT j.a AS a, j.b AS b, j.c AS c FROM (SELECT _0.a AS a, y.b AS b, y.c AS c FROM (SELECT x.a AS a FROM x AS x) AS _0 CROSS JOIN y AS y) AS j;

SELECT * FROM ((x CROSS JOIN w) CROSS JOIN (SELECT c FROM y) AS s) AS j;
SELECT j.a AS a, j.b AS b, j.d AS d, j.e AS e, j.c AS c FROM (SELECT x.a AS a, x.b AS b, w.d AS d, w.e AS e, s.c AS c FROM x AS x CROSS JOIN w AS w CROSS JOIN (SELECT y.c AS c FROM y AS y) AS s) AS j;

SELECT * FROM ((x CROSS JOIN w) AS i CROSS JOIN (SELECT c FROM y) AS s) AS j;
SELECT j.a AS a, j.b AS b, j.d AS d, j.e AS e, j.c AS c FROM (SELECT i.a AS a, i.b AS b, i.d AS d, i.e AS e, s.c AS c FROM (SELECT x.a AS a, x.b AS b, w.d AS d, w.e AS e FROM x AS x CROSS JOIN w AS w) AS i CROSS JOIN (SELECT y.c AS c FROM y AS y) AS s) AS j;

SELECT * FROM ((SELECT a FROM x) CROSS JOIN (w CROSS JOIN (SELECT c FROM y) AS s) AS k) AS j;
SELECT j.a AS a, j.d AS d, j.e AS e, j.c AS c FROM (SELECT _0.a AS a, k.d AS d, k.e AS e, k.c AS c FROM (SELECT x.a AS a FROM x AS x) AS _0 CROSS JOIN (SELECT w.d AS d, w.e AS e, s.c AS c FROM w AS w CROSS JOIN (SELECT y.c AS c FROM y AS y) AS s) AS k) AS j;

SELECT x.a, y.b, z.c FROM x LEFT JOIN (y INNER JOIN z ON y.c = z.c) ON x.b = y.b;
SELECT x.a AS a, y.b AS b, z.c AS c FROM x AS x LEFT JOIN (y AS y INNER JOIN z AS z ON y.c = z.c) ON x.b = y.b;

SELECT * FROM ((SELECT * FROM x) INNER JOIN (SELECT * FROM y) ON a = c);
SELECT _0.a AS a, _0.b AS b, _1.b AS b, _1.c AS c FROM ((SELECT x.a AS a, x.b AS b FROM x AS x) AS _0 INNER JOIN (SELECT y.b AS b, y.c AS c FROM y AS y) AS _1 ON _0.a = _1.c);

# title: outer star over derived table with duplicate output names is left unexpanded
SELECT * FROM (SELECT * FROM x CROSS JOIN y) AS s;
SELECT * FROM (SELECT x.a AS a, x.b AS b, y.b AS b, y.c AS c FROM x AS x CROSS JOIN y AS y) AS s;

# title: qualified outer star over derived table with duplicate output names is left unexpanded
SELECT s.* FROM (SELECT * FROM x CROSS JOIN y) AS s;
SELECT s.* FROM (SELECT x.a AS a, x.b AS b, y.b AS b, y.c AS c FROM x AS x CROSS JOIN y AS y) AS s;

# title: outer star over derived table with distinct output names is expanded normally
SELECT * FROM (SELECT a, c FROM x CROSS JOIN y) AS s;
SELECT s.a AS a, s.c AS c FROM (SELECT x.a AS a, y.c AS c FROM x AS x CROSS JOIN y AS y) AS s;

# title: nested outer stars over duplicate output names are left unexpanded at each level
SELECT * FROM (SELECT * FROM (SELECT * FROM x CROSS JOIN y) AS s) AS t;
SELECT * FROM (SELECT * FROM (SELECT x.a AS a, x.b AS b, y.b AS b, y.c AS c FROM x AS x CROSS JOIN y AS y) AS s) AS t;

# title: user-authored duplicate aliases in a derived table are preserved, not clobbered
SELECT * FROM (SELECT a AS k, a AS k FROM x) AS s;
SELECT * FROM (SELECT x.a AS k, x.a AS k FROM x AS x) AS s;

# title: mixed star and explicit projection in a derived table with duplicate output names is preserved
SELECT * FROM (SELECT *, a AS extra FROM x CROSS JOIN y) AS s;
SELECT * FROM (SELECT x.a AS a, x.b AS b, y.b AS b, y.c AS c, x.a AS extra FROM x AS x CROSS JOIN y AS y) AS s;

SELECT b FROM ((SELECT a FROM x) INNER JOIN y ON a = b);
SELECT y.b AS b FROM ((SELECT x.a AS a FROM x AS x) AS _0 INNER JOIN y AS y ON _0.a = y.b);

SELECT a, c FROM x TABLESAMPLE SYSTEM (10 ROWS) CROSS JOIN y TABLESAMPLE SYSTEM (10 ROWS);
SELECT x.a AS a, y.c AS c FROM x AS x TABLESAMPLE SYSTEM (10 ROWS) CROSS JOIN y AS y TABLESAMPLE SYSTEM (10 ROWS);

SELECT x.a FROM x INNER JOIN y ON x.a = c INNER JOIN z ON x.a = z.c;
SELECT x.a AS a FROM x AS x INNER JOIN y AS y ON x.a = y.c INNER JOIN z AS z ON x.a = z.c;

--------------------------------------
-- Snowflake allows column alias to be used in almost all clauses
--------------------------------------
# title: Snowflake column alias in JOIN
# dialect: snowflake
# execute: false
SELECT x.a AS foo FROM x JOIN y ON foo = y.b;
SELECT X.A AS FOO FROM X AS X JOIN Y AS Y ON X.A = Y.B;

# title: Snowflake column alias in QUALIFY
# dialect: snowflake
# execute: false
SELECT x.a AS foo FROM x QUALIFY foo = 1;
SELECT X.A AS FOO FROM X AS X QUALIFY X.A = 1;

# title: Snowflake column alias in GROUP BY
# dialect: snowflake
# execute: false
SELECT x.a AS foo FROM x GROUP BY foo = 1;
SELECT X.A AS FOO FROM X AS X GROUP BY X.A = 1;

# title: Snowflake column alias in WHERE
# dialect: snowflake
# execute: false
SELECT x.a AS foo FROM x WHERE foo = 1;
SELECT X.A AS FOO FROM X AS X WHERE X.A = 1;


--------------------------------------
-- SEMI / ANTI Joins
--------------------------------------

# title: SEMI JOIN table is excluded from the scope
# dialect: duckdb
SELECT * FROM x SEMI JOIN y USING (b);
SELECT x.a AS a, x.b AS b FROM x AS x SEMI JOIN y AS y ON x.b = y.b;

# title: ANTI JOIN table is excluded from the scope
# dialect: duckdb
SELECT * FROM x ANTI JOIN y USING (b);
SELECT x.a AS a, x.b AS b FROM x AS x ANTI JOIN y AS y ON x.b = y.b;

# title: SEMI JOIN alias shadows a struct column only in its own ON clause
# dialect: duckdb
SELECT s.k FROM (VALUES (1, 10, {'k': 10}), (2, 20, {'k': 99})) AS t(id, k, s) SEMI JOIN (VALUES (20)) AS s(k) ON t.k = s.k WHERE s.k > 0;
SELECT t.s.k AS k FROM (VALUES (1, 10, {'k': 10}), (2, 20, {'k': 99})) AS t(id, k, s) SEMI JOIN (VALUES (20)) AS s(k) ON t.k = s.k WHERE t.s.k > 0;

# title: ANTI JOIN alias does not shadow a struct column in a later join
# dialect: duckdb
SELECT s.k FROM (VALUES (1, 10, {'k': 10}), (2, 20, {'k': 99})) AS t(id, k, s) ANTI JOIN (VALUES (20)) AS s(k) ON t.k = s.k JOIN (VALUES (10)) AS u(k) ON s.k = u.k;
SELECT t.s.k AS k FROM (VALUES (1, 10, {'k': 10}), (2, 20, {'k': 99})) AS t(id, k, s) ANTI JOIN (VALUES (20)) AS s(k) ON t.k = s.k JOIN (VALUES (10)) AS u(k) ON t.s.k = u.k;

# title: SEMI JOIN alias does not shadow a struct column in an earlier join
# dialect: duckdb
SELECT s.k FROM (VALUES (1, 10, {'k': 10}), (2, 20, {'k': 99})) AS t(id, k, s) JOIN (VALUES (99)) AS u(k) ON s.k = u.k SEMI JOIN (VALUES (20)) AS s(k) ON t.k = s.k;
SELECT t.s.k AS k FROM (VALUES (1, 10, {'k': 10}), (2, 20, {'k': 99})) AS t(id, k, s) JOIN (VALUES (99)) AS u(k) ON t.s.k = u.k SEMI JOIN (VALUES (20)) AS s(k) ON t.k = s.k;

# title: SEMI JOIN struct field matches another source alias
# dialect: duckdb
SELECT t.k FROM (VALUES (20, {'k': 99})) AS t(k, s) SEMI JOIN (VALUES ({'k': 20})) AS s(payload) ON t.k = s.payload.k CROSS JOIN (VALUES (1)) AS payload(v);
SELECT t.k AS k FROM (VALUES (20, {'k': 99})) AS t(k, s) SEMI JOIN (VALUES ({'k': 20})) AS s(payload) ON t.k = s.payload.k CROSS JOIN (VALUES (1)) AS payload(v);

# title: Consecutive SEMI and ANTI JOIN aliases are visible only in their own ON clauses
# dialect: duckdb
SELECT s.k, u.k FROM (VALUES (20, {'k': 99}, {'k': 88})) AS t(k, s, u) SEMI JOIN (VALUES (20)) AS s(k) ON t.k = s.k AND s.k = 20 ANTI JOIN (VALUES (20)) AS u(k) ON t.k = u.k AND s.k = 20;
SELECT t.s.k AS k, t.u.k AS k FROM (VALUES (20, {'k': 99}, {'k': 88})) AS t(k, s, u) SEMI JOIN (VALUES (20)) AS s(k) ON t.k = s.k AND s.k = 20 ANTI JOIN (VALUES (20)) AS u(k) ON t.k = u.k AND t.s.k = 20;

# title: SEMI JOIN alias without a matching column preserves struct fallback
# dialect: duckdb
SELECT t.id FROM (VALUES (1, 10, {'k': 10}), (2, 20, {'k': 99})) AS t(id, k, s) SEMI JOIN (VALUES (1)) AS s(v) ON t.k = s.k;
SELECT t.id AS id FROM (VALUES (1, 10, {'k': 10}), (2, 20, {'k': 99})) AS t(id, k, s) SEMI JOIN (VALUES (1)) AS s(v) ON t.k = t.s.k;

# title: ANTI JOIN alias without a matching column preserves nested struct fallback
# dialect: duckdb
SELECT t.id FROM (VALUES (1, 10, {'payload': {'k': 10}}), (2, 20, {'payload': {'k': 99}})) AS t(id, k, s) ANTI JOIN (VALUES (1)) AS s(v) ON t.k = s.payload.k;
SELECT t.id AS id FROM (VALUES (1, 10, {'payload': {'k': 10}}), (2, 20, {'payload': {'k': 99}})) AS t(id, k, s) ANTI JOIN (VALUES (1)) AS s(v) ON t.k = t.s.payload.k;

# title: bare USING column after SEMI JOIN resolves to the left table
# dialect: duckdb
SELECT b FROM x SEMI JOIN y USING (b);
SELECT x.b AS b FROM x AS x SEMI JOIN y AS y ON x.b = y.b;

# title: bare USING column in WHERE after ANTI JOIN resolves to the left table
# dialect: duckdb
SELECT a FROM x ANTI JOIN y USING (b) WHERE b > 0;
SELECT x.a AS a FROM x AS x ANTI JOIN y AS y ON x.b = y.b WHERE x.b > 0;

# title: SEMI join USING columns come first
# dialect: spark
# execute: false
SELECT * FROM x LEFT SEMI JOIN y USING (b);
SELECT x.b AS b, x.a AS a FROM x AS x LEFT SEMI JOIN y AS y ON x.b = y.b;

# title: SEMI join USING columns precede those of earlier joins
# dialect: spark
# execute: false
SELECT * FROM x JOIN y USING (b) LEFT SEMI JOIN z USING (c);
SELECT y.c AS c, COALESCE(x.b, y.b) AS b, x.a AS a FROM x AS x JOIN y AS y ON x.b = y.b LEFT SEMI JOIN z AS z ON y.c = z.c;

# title: SEMI + normal joins reinclude the table on scope
# dialect: duckdb
SELECT * FROM x SEMI JOIN y USING (b) JOIN y USING (b);
SELECT x.a AS a, COALESCE(x.b, y_2.b) AS b, y_2.c AS c FROM x AS x SEMI JOIN y AS y ON x.b = y.b JOIN y AS y_2 ON x.b = y_2.b;

# title: ANTI + normal joins reinclude the table on scope
# dialect: duckdb
SELECT * FROM x ANTI JOIN y USING (b) JOIN y USING (b);
SELECT x.a AS a, COALESCE(x.b, y_2.b) AS b, y_2.c AS c FROM x AS x ANTI JOIN y AS y ON x.b = y.b JOIN y AS y_2 ON x.b = y_2.b;

# title: unqualified column in ANTI JOIN's ON clause resolves to that join's own table, not a later join sharing the same column name
SELECT w.d FROM w ANTI JOIN y ON b > 0 JOIN z ON TRUE;
SELECT w.d AS d FROM w AS w ANTI JOIN y AS y ON y.b > 0 JOIN z AS z ON TRUE;

# title: unqualified column in SEMI JOIN's ON clause resolves to that join's own table, not a later join sharing the same column name
SELECT w.d FROM w SEMI JOIN y ON b > 0 JOIN z ON TRUE;
SELECT w.d AS d FROM w AS w SEMI JOIN y AS y ON y.b > 0 JOIN z AS z ON TRUE;

# title: self-join -- ANTI JOIN's own alias wins over a later normal join of the same table
SELECT w.d FROM w ANTI JOIN x AS x1 ON a > 0 JOIN x AS x2 ON TRUE;
SELECT w.d AS d FROM w AS w ANTI JOIN x AS x1 ON x1.a > 0 JOIN x AS x2 ON TRUE;

# title: derived table (subquery) as the ANTI JOIN's own source -- unqualified column resolves into the derived table, not a later derived source sharing the same column name
SELECT w.d FROM w ANTI JOIN (SELECT a FROM x) AS m ON a > 0 JOIN (SELECT a FROM x) AS n ON TRUE;
SELECT w.d AS d FROM w AS w ANTI JOIN (SELECT x.a AS a FROM x AS x) AS m ON m.a > 0 JOIN (SELECT x.a AS a FROM x AS x) AS n ON TRUE;

# title: unqualified column in a normal JOIN's ON clause that comes after a SEMI JOIN still sees that later join's own table, not the earlier SEMI JOIN's now out-of-scope table
SELECT x.a FROM x SEMI JOIN y ON x.b = y.b JOIN z ON c > 0;
SELECT x.a AS a FROM x AS x SEMI JOIN y AS y ON x.b = y.b JOIN z AS z ON z.c > 0;

# title: chained UNPIVOT, source is a CTE
# dialect: duckdb
WITH t AS (SELECT 1 AS id, 100 AS jan, 200 AS feb, 7 AS north, 8 AS south) SELECT * FROM t UNPIVOT(revenue FOR month IN (jan, feb)) UNPIVOT(headcount FOR region IN (north, south));
WITH t AS (SELECT 1 AS id, 100 AS jan, 200 AS feb, 7 AS north, 8 AS south) SELECT t.id AS id, t.month AS month, t.revenue AS revenue, t.region AS region, t.headcount AS headcount FROM t AS t UNPIVOT(revenue FOR month IN (jan, feb)) UNPIVOT(headcount FOR region IN (north, south)) AS t;

# title: chained UNPIVOT, source columns come from the schema
# dialect: duckdb
SELECT * FROM unpivotable UNPIVOT(revenue FOR month IN (jan, feb)) UNPIVOT(headcount FOR region IN (north, south));
SELECT unpivotable.id AS id, unpivotable.month AS month, unpivotable.revenue AS revenue, unpivotable.region AS region, unpivotable.headcount AS headcount FROM unpivotable AS unpivotable UNPIVOT(revenue FOR month IN (jan, feb)) UNPIVOT(headcount FOR region IN (north, south)) AS unpivotable;

# title: chained UNPIVOT, explicit columns under the chain's alias
# dialect: duckdb
WITH t AS (SELECT 1 AS id, 100 AS jan, 200 AS feb, 7 AS north, 8 AS south) SELECT u.month, u.headcount FROM t UNPIVOT(revenue FOR month IN (jan, feb)) UNPIVOT(headcount FOR region IN (north, south)) AS u;
WITH t AS (SELECT 1 AS id, 100 AS jan, 200 AS feb, 7 AS north, 8 AS south) SELECT u.month AS month, u.headcount AS headcount FROM t AS t UNPIVOT(revenue FOR month IN (jan, feb)) UNPIVOT(headcount FOR region IN (north, south)) AS u;

# title: chained PIVOT, the second groups by what the first produced
# dialect: duckdb
SELECT * FROM pivotable PIVOT(SUM(val) FOR cat IN ('a' AS a, 'b' AS b)) PIVOT(SUM(amt) FOR kind IN ('x' AS x, 'y' AS y));
SELECT _0.id AS id, _0.a AS a, _0.b AS b, _0.x AS x, _0.y AS y FROM pivotable AS pivotable PIVOT(SUM(val) FOR cat IN ('a' AS a, 'b' AS b)) PIVOT(SUM(amt) FOR kind IN ('x' AS x, 'y' AS y)) AS _0;

# title: PIVOT then UNPIVOT of the columns it produced
# dialect: duckdb
SELECT * FROM pivotable PIVOT(SUM(val) FOR cat IN ('a' AS a, 'b' AS b)) UNPIVOT(v FOR c IN (a, b));
SELECT pivotable.id AS id, pivotable.kind AS kind, pivotable.amt AS amt, pivotable.c AS c, pivotable.v AS v FROM pivotable AS pivotable PIVOT(SUM(val) FOR cat IN ('a' AS a, 'b' AS b)) UNPIVOT(v FOR c IN (a, b)) AS pivotable;

# title: a source joined next to a pivoted one is not expanded through its operators
# dialect: duckdb
SELECT * FROM x JOIN unpivotable UNPIVOT(revenue FOR month IN (jan, feb)) AS u ON x.a = u.id;
SELECT x.a AS a, x.b AS b, u.id AS id, u.north AS north, u.south AS south, u.month AS month, u.revenue AS revenue FROM x AS x JOIN unpivotable AS unpivotable UNPIVOT(revenue FOR month IN (jan, feb)) AS u ON x.a = u.id;

# title: chained UNPIVOT keeps quoted identifiers case-sensitive, unlike the names it produces
# execute: false
# dialect: snowflake
WITH t AS (SELECT 1 AS "Id", 2 AS "Jan", 3 AS "Feb", 4 AS "Nor", 5 AS "Sou") SELECT * FROM t UNPIVOT(v1 FOR n1 IN ("Jan", "Feb")) UNPIVOT(v2 FOR n2 IN ("Nor", "Sou"));
WITH T AS (SELECT 1 AS "Id", 2 AS "Jan", 3 AS "Feb", 4 AS "Nor", 5 AS "Sou") SELECT T."Id" AS "Id", T.N1 AS N1, T.V1 AS V1, T.N2 AS N2, T.V2 AS V2 FROM T AS T UNPIVOT(V1 FOR N1 IN ("Jan", "Feb")) UNPIVOT(V2 FOR N2 IN ("Nor", "Sou")) AS T;

# title: qualified star over the pivot alias of a pivoted table
# dialect: duckdb
SELECT u.* FROM unpivotable UNPIVOT(revenue FOR month IN (jan, feb)) AS u;
SELECT u.id AS id, u.north AS north, u.south AS south, u.month AS month, u.revenue AS revenue FROM unpivotable AS unpivotable UNPIVOT(revenue FOR month IN (jan, feb)) AS u;

# title: qualified star over the pivot alias, next to a joined plain source
# dialect: duckdb
SELECT x.b, u.* FROM x JOIN unpivotable UNPIVOT(revenue FOR month IN (jan, feb)) AS u ON x.a = u.id;
SELECT x.b AS b, u.id AS id, u.north AS north, u.south AS south, u.month AS month, u.revenue AS revenue FROM x AS x JOIN unpivotable AS unpivotable UNPIVOT(revenue FOR month IN (jan, feb)) AS u ON x.a = u.id;

# title: qualified star over the pivot alias of a pivoted CTE
# dialect: duckdb
WITH c AS (SELECT id, jan, feb FROM unpivotable) SELECT piv.* FROM c UNPIVOT(revenue FOR month IN (jan, feb)) AS piv;
WITH c AS (SELECT unpivotable.id AS id, unpivotable.jan AS jan, unpivotable.feb AS feb FROM unpivotable AS unpivotable) SELECT piv.id AS id, piv.month AS month, piv.revenue AS revenue FROM c AS c UNPIVOT(revenue FOR month IN (jan, feb)) AS piv;

# title: qualified star over the pivot alias of an aliased pivoted CTE
# dialect: duckdb
WITH c AS (SELECT id, jan, feb FROM unpivotable) SELECT piv.* FROM c AS m UNPIVOT(revenue FOR month IN (jan, feb)) AS piv;
WITH c AS (SELECT unpivotable.id AS id, unpivotable.jan AS jan, unpivotable.feb AS feb FROM unpivotable AS unpivotable) SELECT piv.id AS id, piv.month AS month, piv.revenue AS revenue FROM c AS m UNPIVOT(revenue FOR month IN (jan, feb)) AS piv;

# title: UNPIVOT over an aliased CTE that also has an UNPIVOT alias
# execute: false
# dialect: snowflake
WITH base AS (SELECT id, jan, feb FROM unpivotable) SELECT p.amount FROM base AS m UNPIVOT(amount FOR metric IN (jan, feb)) AS p;
WITH BASE AS (SELECT UNPIVOTABLE.ID AS ID, UNPIVOTABLE.JAN AS JAN, UNPIVOTABLE.FEB AS FEB FROM UNPIVOTABLE AS UNPIVOTABLE) SELECT P.AMOUNT AS AMOUNT FROM BASE AS M UNPIVOT(AMOUNT FOR METRIC IN (JAN, FEB)) AS P;

# title: qualified star over the pivot alias of a pivoted subquery
# dialect: duckdb
SELECT piv.* FROM (SELECT id, jan, feb FROM unpivotable) UNPIVOT(revenue FOR month IN (jan, feb)) AS piv;
SELECT piv.id AS id, piv.month AS month, piv.revenue AS revenue FROM (SELECT unpivotable.id AS id, unpivotable.jan AS jan, unpivotable.feb AS feb FROM unpivotable AS unpivotable) AS _0 UNPIVOT(revenue FOR month IN (jan, feb)) AS piv;

# title: qualified star over the alias of a chain of operators
# dialect: duckdb
SELECT u.* FROM unpivotable UNPIVOT(revenue FOR month IN (jan, feb)) UNPIVOT(headcount FOR region IN (north, south)) AS u;
SELECT u.id AS id, u.month AS month, u.revenue AS revenue, u.region AS region, u.headcount AS headcount FROM unpivotable AS unpivotable UNPIVOT(revenue FOR month IN (jan, feb)) UNPIVOT(headcount FOR region IN (north, south)) AS u;

# title: resolve Snowflake positional references inside composed expressions
# execute: false
# dialect: snowflake
WITH t AS (SELECT PARSE_JSON('{"id": 1}') AS data, 'file' AS filepath) SELECT t.$1:"id"::INT AS id, t.$2 AS filename FROM t;
WITH T AS (SELECT PARSE_JSON('{"id": 1}') AS DATA, 'file' AS FILEPATH) SELECT CAST(GET_PATH(T.DATA, 'id') AS INT) AS ID, T.FILEPATH AS FILENAME FROM T AS T;

# title: resolve Snowflake positional reference to a quoted column
# execute: false
# dialect: snowflake
WITH t AS (SELECT 1 AS "lower") SELECT t.$1 FROM t;
WITH T AS (SELECT 1 AS "lower") SELECT T."lower" AS "lower" FROM T AS T;

# title: preserve explicit quotes when resolving Snowflake positional references
# execute: false
# dialect: snowflake
WITH t AS (SELECT 1 AS "SELECT") SELECT t.$1 FROM t;
WITH T AS (SELECT 1 AS "SELECT") SELECT T."SELECT" AS "SELECT" FROM T AS T;

# title: preserve ambiguous Snowflake positional reference and resolve unique one
# execute: false
# dialect: snowflake
WITH t AS (SELECT 1 AS x, 2 AS x, 3 AS y) SELECT t.$2, t.$3 FROM t;
WITH T AS (SELECT 1 AS X, 2 AS X, 3 AS Y) SELECT T.$2 AS _COL_0, T.Y AS Y FROM T AS T;

# title: resolve Snowflake positional reference with CTE column aliases
# execute: false
# dialect: snowflake
WITH t("lower") AS (SELECT 1) SELECT t.$1 FROM t;
WITH T AS (SELECT 1 AS "lower") SELECT T."lower" AS "lower" FROM T AS T;

# title: preserve Snowflake positional reference through UNPIVOT
# execute: false
# dialect: snowflake
WITH t AS (SELECT 1 AS "SELECT", 2 AS a, 3 AS b) SELECT t.$1 FROM t UNPIVOT(v FOR k IN (a, b));
WITH T AS (SELECT 1 AS "SELECT", 2 AS A, 3 AS B) SELECT T.$1 AS _COL_0 FROM T AS T UNPIVOT(V FOR K IN (A, B)) AS T;

# title: preserve Snowflake positional reference through aliased PIVOT
# execute: false
# dialect: snowflake
WITH t AS (SELECT 1 AS id, 2 AS v, 'a' AS k) SELECT p.$2 FROM t PIVOT(SUM(v) FOR k IN ('a' AS "SELECT")) AS p;
WITH T AS (SELECT 1 AS ID, 2 AS V, 'a' AS K) SELECT P.$2 AS _COL_0 FROM T AS T PIVOT(SUM(T.V) FOR T.K IN ('a' AS "SELECT")) AS P;

# title: retarget Snowflake positional reference to generated PIVOT alias
# execute: false
# dialect: snowflake
WITH t AS (SELECT 1 AS id, 2 AS v, 'a' AS k) SELECT t.$2 FROM t PIVOT(SUM(v) FOR k IN ('a' AS a));
WITH T AS (SELECT 1 AS ID, 2 AS V, 'a' AS K) SELECT _0.$2 AS _COL_0 FROM T AS T PIVOT(SUM(T.V) FOR T.K IN ('a' AS A)) AS _0;

# title: retarget Snowflake positional reference to final chained operator
# execute: false
# dialect: snowflake
WITH t AS (SELECT 1 AS id, 2 AS v, 'a' AS k) SELECT t.$1 FROM t PIVOT(SUM(v) FOR k IN ('a' AS a)) UNPIVOT(v2 FOR k2 IN (a));
WITH T AS (SELECT 1 AS ID, 2 AS V, 'a' AS K) SELECT T.$1 AS _COL_0 FROM T AS T PIVOT(SUM(T.V) FOR T.K IN ('a' AS A)) UNPIVOT(V2 FOR K2 IN (A)) AS T;

# title: resolve Snowflake positional reference beside unrelated PIVOT
# execute: false
# dialect: snowflake
WITH t AS (SELECT 1 AS x), s AS (SELECT 1 AS id, 2 AS v, 'a' AS k) SELECT t.$1, p.$2 FROM t CROSS JOIN s PIVOT(SUM(v) FOR k IN ('a' AS a)) AS p;
WITH T AS (SELECT 1 AS X), S AS (SELECT 1 AS ID, 2 AS V, 'a' AS K) SELECT T.X AS X, P.$2 AS _COL_1 FROM T AS T CROSS JOIN S AS S PIVOT(SUM(S.V) FOR S.K IN ('a' AS A)) AS P;

# title: resolve Snowflake positional reference with table alias column list
# execute: false
# dialect: snowflake
SELECT x.$1, x.$2 FROM x AS x(alias_name);
SELECT X.ALIAS_NAME AS ALIAS_NAME, X.B AS B FROM X AS X(ALIAS_NAME);

# title: preserve Snowflake positional reference from unknown source
# execute: false
# dialect: snowflake
SELECT t.$1 FROM source AS t;
SELECT T.$1 AS _COL_0 FROM SOURCE AS T;

# title: preserve Snowflake positional reference from star source
# execute: false
# dialect: snowflake
WITH t AS (SELECT * FROM source) SELECT t.$1 FROM t;
WITH T AS (SELECT * FROM SOURCE AS SOURCE) SELECT T.$1 AS _COL_0 FROM T AS T;

# title: preserve Snowflake positional reference beyond partial table alias list
# execute: false
# dialect: snowflake
SELECT x.$2 FROM unknown AS x(alias_name);
SELECT X.$2 AS _COL_0 FROM UNKNOWN AS X(ALIAS_NAME);


# title: MySQL lists multiple USING columns first in the left table's order
# dialect: mysql
# execute: false
SELECT * FROM y JOIN z USING (c, b);
SELECT COALESCE(y.b, z.b) AS b, COALESCE(y.c, z.c) AS c FROM y AS y JOIN z AS z ON y.c = z.c AND y.b = z.b;

# title: BigQuery unpivot row alias takes precedence over a same-named input column
# dialect: bigquery
# execute: false
SELECT unp FROM (SELECT 7 AS unp, 1 AS a, 2 AS b) UNPIVOT(v FOR k IN (a, b)) AS unp;
SELECT unp AS unp FROM (SELECT 7 AS unp, 1 AS a, 2 AS b) AS _0 UNPIVOT(v FOR k IN (_0.a, _0.b)) AS unp;

# title: BigQuery pivot row alias resolves without a source schema
# dialect: bigquery
# execute: false
SELECT ARRAY_AGG(piv) AS arr FROM unknown_table AS u PIVOT(SUM(u.v) FOR u.k IN (82 AS a)) AS piv;
SELECT ARRAY_AGG(piv) AS arr FROM unknown_table AS u PIVOT(SUM(u.v) FOR u.k IN (82 AS a)) AS piv;
